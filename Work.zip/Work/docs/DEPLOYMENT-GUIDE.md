# Deployment Guide — Power Platform Enterprise Governance Report

**Target:** Fortune 100 enterprise deployment on Microsoft Azure
**Runtime:** Azure Container App Job (scheduled)
**Output:** Azure Blob Storage (CSV files consumed by Power BI)
**Last Updated:** 2026-04-27

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Architecture Overview](#2-architecture-overview)
3. [Phase 1 — Azure Foundation](#3-phase-1--azure-foundation)
4. [Phase 2 — Identity and Permissions](#4-phase-2--identity-and-permissions)
5. [Phase 3 — Network Infrastructure](#5-phase-3--network-infrastructure)
6. [Phase 4 — Build and Push Container Image](#6-phase-4--build-and-push-container-image)
7. [Phase 5 — Deploy Application Infrastructure](#7-phase-5--deploy-application-infrastructure)
8. [Phase 6 — Configuration and Validation](#8-phase-6--configuration-and-validation)
9. [Phase 7 — Power BI Dashboard Setup](#9-phase-7--power-bi-dashboard-setup)
10. [Phase 8 — Production Hardening](#10-phase-8--production-hardening)
11. [GitLab CI/CD Pipeline](#11-gitlab-cicd-pipeline)
12. [Operations Runbook](#12-operations-runbook)
13. [Troubleshooting](#13-troubleshooting)
14. [Disaster Recovery](#14-disaster-recovery)
15. [Cost Estimation](#15-cost-estimation)

---

## 1. Prerequisites

### 1.1 Azure Subscriptions and Permissions

| Requirement | Details |
|------------|---------|
| Azure subscription | Enterprise Agreement or MCA with sufficient quota |
| Subscription-level role | Owner or User Access Administrator (for role assignments) |
| Azure AD role | Application Administrator (for app registration) |
| Power Platform role | Power Platform Admin or Global Admin |
| Resource providers | `Microsoft.App`, `Microsoft.Storage`, `Microsoft.ContainerRegistry`, `Microsoft.ManagedIdentity`, `Microsoft.Network`, `Microsoft.KeyVault`, `Microsoft.Insights` |

### 1.2 Tooling

| Tool | Version | Purpose |
|------|---------|---------|
| Azure CLI | >= 2.60 | Infrastructure deployment, credential management |
| Docker Desktop or Podman | Latest | Container image build |
| Python | >= 3.12 | Local development/testing |
| Power BI Desktop | Latest | Dashboard development |
| Git | Latest | Source control |
| Bicep CLI | >= 0.25 (bundled with Azure CLI) | Infrastructure as Code |

### 1.3 Network Requirements

The Container App Job requires outbound HTTPS (443) access to:

| Endpoint | Purpose |
|----------|---------|
| `login.microsoftonline.com` | Azure AD token acquisition |
| `*.powerapps.com` | Power Apps API |
| `*.flow.microsoft.com` | Power Automate API |
| `*.bap.microsoft.com` | Business Application Platform API |
| `*.api.powerplatform.com` | Power Platform Admin API |
| `*.crm.dynamics.com` (and regional variants) | Dataverse API |
| `graph.microsoft.com` | Microsoft Graph API |
| `*.blob.core.windows.net` | Azure Blob Storage (or private endpoint) |
| `*.azurecr.io` | Azure Container Registry (or private endpoint) |

### 1.4 Naming Convention

This guide uses the following naming convention. Replace with your organization's standards:

```
Environment prefix:  ppgov (Power Platform Governance)
Resource Group:      rg-ppgov-prod-eastus2
Managed Identity:    id-ppgov-prod
Storage Account:     stppgovprodeus2 (max 24 chars, lowercase alphanumeric)
Container Registry:  crppgovprod
Container App Env:   cae-ppgov-prod
Container App Job:   caj-ppgov-prod
Key Vault:           kv-ppgov-prod
VNet:                vnet-ppgov-prod
Log Analytics:       log-ppgov-prod
```

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          Azure Subscription                             │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐   │
│  │                    Resource Group: rg-ppgov-prod                   │   │
│  │                                                                     │   │
│  │  ┌──────────────────────────────────────────────────────────────┐   │   │
│  │  │                 Virtual Network: vnet-ppgov-prod              │   │   │
│  │  │                    10.100.0.0/16                               │   │   │
│  │  │                                                                │   │   │
│  │  │  ┌─────────────────────────┐  ┌────────────────────────────┐   │   │   │
│  │  │  │ Subnet: snet-cae        │  │ Subnet: snet-pe            │   │   │   │
│  │  │  │ 10.100.1.0/23           │  │ 10.100.4.0/24              │   │   │   │
│  │  │  │                         │  │                            │   │   │   │
│  │  │  │ [Container App Job]     │  │ PE: Storage Account        │   │   │   │
│  │  │  │  ↕ HTTPS                │  │ PE: Container Registry     │   │   │   │
│  │  │  │  Power Platform APIs    │  │ PE: Key Vault              │   │   │   │
│  │  │  │  Microsoft Graph        │  │                            │   │   │   │
│  │  │  │  Azure AD               │  │                            │   │   │   │
│  │  │  └─────────────────────────┘  └────────────────────────────┘   │   │   │
│  │  └──────────────────────────────────────────────────────────────┘   │   │
│  │                                                                     │   │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────┐   │   │
│  │  │ Storage Acct  │ │ Container    │ │ Key Vault    │ │ Log      │   │   │
│  │  │ (Blob CSVs)   │ │ Registry     │ │ (CMK keys)   │ │ Analytics│   │   │
│  │  │ GRS encrypted │ │ (images)     │ │              │ │          │   │   │
│  │  └──────────────┘ └──────────────┘ └──────────────┘ └──────────┘   │   │
│  │                                                                     │   │
│  │  ┌──────────────┐                                                   │   │
│  │  │ Managed      │  Used by: Container App Job                       │   │
│  │  │ Identity     │  Permissions: PP Admin Read, Graph Read,          │   │
│  │  │              │  Storage Blob Data Contributor, AcrPull            │   │
│  │  └──────────────┘                                                   │   │
│  └───────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │              Power BI Service / Desktop                           │    │
│  │              Connects to Storage Account (Reader role)            │    │
│  └──────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Phase 1 — Azure Foundation

### 3.1 Register Resource Providers

```bash
az provider register --namespace Microsoft.App
az provider register --namespace Microsoft.Storage
az provider register --namespace Microsoft.ContainerRegistry
az provider register --namespace Microsoft.ManagedIdentity
az provider register --namespace Microsoft.Network
az provider register --namespace Microsoft.KeyVault
az provider register --namespace Microsoft.Insights
az provider register --namespace Microsoft.OperationalInsights
```

### 3.2 Create Resource Group

```bash
LOCATION="eastus2"
RG_NAME="rg-ppgov-prod-eastus2"

az group create \
  --name "$RG_NAME" \
  --location "$LOCATION" \
  --tags \
    environment=production \
    application=ppgov \
    costCenter=IT-Governance \
    owner=platform-engineering
```

### 3.3 Create Log Analytics Workspace

```bash
az monitor log-analytics workspace create \
  --resource-group "$RG_NAME" \
  --workspace-name "log-ppgov-prod" \
  --location "$LOCATION" \
  --retention-in-days 90 \
  --sku PerGB2018
```

Capture the workspace ID:

```bash
LOG_WORKSPACE_ID=$(az monitor log-analytics workspace show \
  --resource-group "$RG_NAME" \
  --workspace-name "log-ppgov-prod" \
  --query id -o tsv)
```

---

## 4. Phase 2 — Identity and Permissions

### 4.1 Create User-Assigned Managed Identity

```bash
IDENTITY_NAME="id-ppgov-prod"

az identity create \
  --resource-group "$RG_NAME" \
  --name "$IDENTITY_NAME" \
  --location "$LOCATION"

# Capture outputs
IDENTITY_ID=$(az identity show -g "$RG_NAME" -n "$IDENTITY_NAME" --query id -o tsv)
IDENTITY_PRINCIPAL=$(az identity show -g "$RG_NAME" -n "$IDENTITY_NAME" --query principalId -o tsv)
IDENTITY_CLIENT=$(az identity show -g "$RG_NAME" -n "$IDENTITY_NAME" --query clientId -o tsv)
```

### 4.2 Create Azure AD App Registration for Power Platform Access

The managed identity needs API permissions that require an app registration:

```bash
# Create app registration
APP_NAME="ppgov-export-prod"

az ad app create \
  --display-name "$APP_NAME" \
  --sign-in-audience AzureADMyOrg

APP_ID=$(az ad app list --display-name "$APP_NAME" --query '[0].appId' -o tsv)
APP_OBJECT_ID=$(az ad app list --display-name "$APP_NAME" --query '[0].id' -o tsv)
```

### 4.3 Configure API Permissions

Add required API permissions to the app registration. These must be granted **admin consent** by a Global Admin or Privileged Role Admin.

```bash
# Microsoft Graph — User.Read.All (Application)
az ad app permission add \
  --id "$APP_ID" \
  --api 00000003-0000-0000-c000-000000000000 \
  --api-permissions df021288-bdef-4463-88db-98f22de89214=Role

# Microsoft Graph — AuditLog.Read.All (Application, for signInActivity)
az ad app permission add \
  --id "$APP_ID" \
  --api 00000003-0000-0000-c000-000000000000 \
  --api-permissions b0afded3-3588-46d8-8b3d-9842eff778da=Role

# Power Apps Service — read access (via Dynamics CRM API)
# The Power Platform admin APIs use the Dynamics CRM resource:
# 00000007-0000-0000-c000-000000000000
az ad app permission add \
  --id "$APP_ID" \
  --api 00000007-0000-0000-c000-000000000000 \
  --api-permissions 78ce3f0f-a1ce-49c2-8cde-64b5c0896db4=Role

# Grant admin consent (requires Global Admin / Privileged Role Admin)
az ad app permission admin-consent --id "$APP_ID"
```

> **Important:** The exact Power Platform API permission GUIDs vary by tenant configuration. Work with your Azure AD administrator to identify the correct permissions. The Power Platform Admin connector may require the "Power Platform Admin" Azure AD role assigned directly to the managed identity's service principal, rather than API permissions.

### 4.4 Assign Power Platform Admin Role

For full tenant-wide environment enumeration, the managed identity needs the Power Platform Admin role:

```bash
# Create service principal for the managed identity (if not auto-created)
SP_ID=$(az ad sp show --id "$IDENTITY_CLIENT" --query id -o tsv 2>/dev/null)

# Assign Power Platform Service Admin role
# Role template ID: 11648597-926c-4cf3-9c36-bcebb0ba8dcc
az rest --method POST \
  --url "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments" \
  --body "{
    \"@odata.type\": \"#microsoft.graph.unifiedRoleAssignment\",
    \"principalId\": \"$IDENTITY_PRINCIPAL\",
    \"roleDefinitionId\": \"11648597-926c-4cf3-9c36-bcebb0ba8dcc\",
    \"directionScopeId\": \"/\"
  }"
```

> **Alternative (Least Privilege):** Instead of Power Platform Admin, consider creating a custom role with only read access to environments, apps, flows, and DLP policies. Consult your Azure AD team.

### 4.5 Assign Federated Credential (Workload Identity)

If using workload identity federation instead of direct managed identity:

```bash
az ad app federated-credential create \
  --id "$APP_OBJECT_ID" \
  --parameters "{
    \"name\": \"ppgov-container-app\",
    \"issuer\": \"https://oidc.prod-aks.azure.com/<tenant-id>/\",
    \"subject\": \"system:serviceaccount:ppgov:ppgov-export\",
    \"audiences\": [\"api://AzureADTokenExchange\"]
  }"
```

---

## 5. Phase 3 — Network Infrastructure

### 5.1 Create Virtual Network and Subnets

```bash
VNET_NAME="vnet-ppgov-prod"

# Create VNet
az network vnet create \
  --resource-group "$RG_NAME" \
  --name "$VNET_NAME" \
  --location "$LOCATION" \
  --address-prefix 10.100.0.0/16

# Container Apps Environment subnet (requires /23 minimum)
az network vnet subnet create \
  --resource-group "$RG_NAME" \
  --vnet-name "$VNET_NAME" \
  --name snet-cae \
  --address-prefix 10.100.1.0/23

# Private endpoints subnet
az network vnet subnet create \
  --resource-group "$RG_NAME" \
  --vnet-name "$VNET_NAME" \
  --name snet-pe \
  --address-prefix 10.100.4.0/24 \
  --disable-private-endpoint-network-policies true
```

### 5.2 Create Network Security Group

```bash
NSG_NAME="nsg-ppgov-cae"

az network nsg create \
  --resource-group "$RG_NAME" \
  --name "$NSG_NAME" \
  --location "$LOCATION"

# Allow outbound HTTPS to Azure AD
az network nsg rule create \
  --resource-group "$RG_NAME" \
  --nsg-name "$NSG_NAME" \
  --name AllowAzureAD \
  --priority 100 \
  --direction Outbound \
  --access Allow \
  --protocol Tcp \
  --destination-port-ranges 443 \
  --destination-address-prefixes AzureActiveDirectory

# Allow outbound HTTPS to Internet (Power Platform APIs)
az network nsg rule create \
  --resource-group "$RG_NAME" \
  --nsg-name "$NSG_NAME" \
  --name AllowHTTPSOutbound \
  --priority 200 \
  --direction Outbound \
  --access Allow \
  --protocol Tcp \
  --destination-port-ranges 443 \
  --destination-address-prefixes Internet

# Deny all other outbound
az network nsg rule create \
  --resource-group "$RG_NAME" \
  --nsg-name "$NSG_NAME" \
  --name DenyAllOutbound \
  --priority 4096 \
  --direction Outbound \
  --access Deny \
  --protocol '*' \
  --destination-port-ranges '*' \
  --destination-address-prefixes '*'

# Deny all inbound
az network nsg rule create \
  --resource-group "$RG_NAME" \
  --nsg-name "$NSG_NAME" \
  --name DenyAllInbound \
  --priority 4096 \
  --direction Inbound \
  --access Deny \
  --protocol '*' \
  --source-port-ranges '*' \
  --destination-port-ranges '*' \
  --source-address-prefixes '*' \
  --destination-address-prefixes '*'

# Associate NSG with CAE subnet
az network vnet subnet update \
  --resource-group "$RG_NAME" \
  --vnet-name "$VNET_NAME" \
  --name snet-cae \
  --network-security-group "$NSG_NAME"
```

### 5.3 Create Private DNS Zones

```bash
# Blob storage
az network private-dns zone create \
  --resource-group "$RG_NAME" \
  --name "privatelink.blob.core.windows.net"

az network private-dns link vnet create \
  --resource-group "$RG_NAME" \
  --zone-name "privatelink.blob.core.windows.net" \
  --name "link-ppgov" \
  --virtual-network "$VNET_NAME" \
  --registration-enabled false

# Container registry
az network private-dns zone create \
  --resource-group "$RG_NAME" \
  --name "privatelink.azurecr.io"

az network private-dns link vnet create \
  --resource-group "$RG_NAME" \
  --zone-name "privatelink.azurecr.io" \
  --name "link-ppgov" \
  --virtual-network "$VNET_NAME" \
  --registration-enabled false

# Key Vault
az network private-dns zone create \
  --resource-group "$RG_NAME" \
  --name "privatelink.vaultcore.azure.net"

az network private-dns link vnet create \
  --resource-group "$RG_NAME" \
  --zone-name "privatelink.vaultcore.azure.net" \
  --name "link-ppgov" \
  --virtual-network "$VNET_NAME" \
  --registration-enabled false
```

---

## 6. Phase 4 — Build and Push Container Image

### 6.1 Create Azure Container Registry

```bash
ACR_NAME="crppgovprod"

az acr create \
  --resource-group "$RG_NAME" \
  --name "$ACR_NAME" \
  --sku Premium \
  --location "$LOCATION" \
  --admin-enabled false \
  --public-network-enabled false

# Create private endpoint for ACR
az network private-endpoint create \
  --resource-group "$RG_NAME" \
  --name "${ACR_NAME}-pe" \
  --vnet-name "$VNET_NAME" \
  --subnet snet-pe \
  --private-connection-resource-id $(az acr show -n "$ACR_NAME" --query id -o tsv) \
  --group-id registry \
  --connection-name "acr-connection"

# Link to private DNS
az network private-endpoint dns-zone-group create \
  --resource-group "$RG_NAME" \
  --endpoint-name "${ACR_NAME}-pe" \
  --name "acr-dns-group" \
  --private-dns-zone "privatelink.azurecr.io" \
  --zone-name "acr"
```

### 6.2 Grant AcrPull to Managed Identity

```bash
ACR_ID=$(az acr show -n "$ACR_NAME" --query id -o tsv)

az role assignment create \
  --assignee-object-id "$IDENTITY_PRINCIPAL" \
  --assignee-principal-type ServicePrincipal \
  --role AcrPull \
  --scope "$ACR_ID"
```

### 6.3 Fix and Build the Docker Image

> **Critical:** The current Dockerfile has a build order bug. Use this corrected version:

Create the fixed Dockerfile at `powerplatform-export/Dockerfile`:

```dockerfile
# Build stage — install dependencies and package
FROM python:3.12-slim AS builder
WORKDIR /build

COPY pyproject.toml ./
COPY src/ ./src/

RUN pip install --no-cache-dir --prefix=/install .

# Runtime stage — minimal image
FROM python:3.12-slim

WORKDIR /app

RUN groupadd -r appuser && useradd -r -g appuser -d /app appuser

# Copy installed packages from builder
COPY --from=builder /install /usr/local

# Copy source (needed for python -m invocation)
COPY src/ ./src/

RUN chown -R appuser:appuser /app
USER appuser

ENTRYPOINT ["python", "-m", "pp_export"]
```

### 6.4 Build and Push

```bash
cd powerplatform-export

# Login to ACR (uses az CLI credentials)
az acr login --name "$ACR_NAME"

# Build with a specific tag (use commit SHA for traceability)
GIT_SHA=$(git rev-parse --short HEAD)
IMAGE_TAG="v1.0.0-${GIT_SHA}"

docker build -t "${ACR_NAME}.azurecr.io/pp-export:${IMAGE_TAG}" .
docker build -t "${ACR_NAME}.azurecr.io/pp-export:latest" .

# Push both tags
docker push "${ACR_NAME}.azurecr.io/pp-export:${IMAGE_TAG}"
docker push "${ACR_NAME}.azurecr.io/pp-export:latest"

# Verify
az acr repository show-tags --name "$ACR_NAME" --repository pp-export
```

### 6.5 Image Scanning

```bash
# Scan with Trivy (run before push)
trivy image --severity CRITICAL,HIGH "${ACR_NAME}.azurecr.io/pp-export:${IMAGE_TAG}"

# Enable Defender for Container Registries (continuous scanning)
az security pricing create \
  --name ContainerRegistry \
  --tier Standard
```

---

## 7. Phase 5 — Deploy Application Infrastructure

### 7.1 Create Key Vault (for CMK)

```bash
KV_NAME="kv-ppgov-prod"

az keyvault create \
  --resource-group "$RG_NAME" \
  --name "$KV_NAME" \
  --location "$LOCATION" \
  --enable-soft-delete true \
  --enable-purge-protection true \
  --retention-days 90 \
  --sku premium \
  --public-network-access Disabled

# Create private endpoint for Key Vault
az network private-endpoint create \
  --resource-group "$RG_NAME" \
  --name "${KV_NAME}-pe" \
  --vnet-name "$VNET_NAME" \
  --subnet snet-pe \
  --private-connection-resource-id $(az keyvault show -n "$KV_NAME" --query id -o tsv) \
  --group-id vault \
  --connection-name "kv-connection"

# Create CMK encryption key
az keyvault key create \
  --vault-name "$KV_NAME" \
  --name "ppgov-cmk" \
  --kty RSA \
  --size 2048 \
  --ops encrypt decrypt wrapKey unwrapKey

# Grant Key Vault Crypto User to managed identity
az role assignment create \
  --assignee-object-id "$IDENTITY_PRINCIPAL" \
  --assignee-principal-type ServicePrincipal \
  --role "Key Vault Crypto User" \
  --scope $(az keyvault show -n "$KV_NAME" --query id -o tsv)
```

### 7.2 Create Storage Account

```bash
STORAGE_NAME="stppgovprodeus2"

az storage account create \
  --resource-group "$RG_NAME" \
  --name "$STORAGE_NAME" \
  --location "$LOCATION" \
  --sku Standard_GRS \
  --kind StorageV2 \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false \
  --https-only true \
  --allow-shared-key-access false \
  --public-network-access Disabled \
  --encryption-key-source Microsoft.Keyvault \
  --encryption-key-vault "https://${KV_NAME}.vault.azure.net" \
  --encryption-key-name "ppgov-cmk" \
  --identity-type UserAssigned \
  --user-identity-id "$IDENTITY_ID" \
  --encryption-key-type-for-table Account \
  --encryption-key-type-for-queue Account

# Create blob container
az storage container create \
  --name "pp-export" \
  --account-name "$STORAGE_NAME" \
  --auth-mode login

# Grant Storage Blob Data Contributor to managed identity
STORAGE_ID=$(az storage account show -n "$STORAGE_NAME" --query id -o tsv)

az role assignment create \
  --assignee-object-id "$IDENTITY_PRINCIPAL" \
  --assignee-principal-type ServicePrincipal \
  --role "Storage Blob Data Contributor" \
  --scope "$STORAGE_ID"

# Create private endpoint for storage
az network private-endpoint create \
  --resource-group "$RG_NAME" \
  --name "${STORAGE_NAME}-pe" \
  --vnet-name "$VNET_NAME" \
  --subnet snet-pe \
  --private-connection-resource-id "$STORAGE_ID" \
  --group-id blob \
  --connection-name "storage-connection"

az network private-endpoint dns-zone-group create \
  --resource-group "$RG_NAME" \
  --endpoint-name "${STORAGE_NAME}-pe" \
  --name "storage-dns-group" \
  --private-dns-zone "privatelink.blob.core.windows.net" \
  --zone-name "blob"
```

### 7.3 Create Blob Lifecycle Policy

```bash
az storage account management-policy create \
  --account-name "$STORAGE_NAME" \
  --resource-group "$RG_NAME" \
  --policy '{
    "rules": [
      {
        "name": "cool-after-30d",
        "type": "Lifecycle",
        "definition": {
          "actions": {
            "baseBlob": {
              "tierToCool": { "daysAfterModificationGreaterThan": 30 },
              "tierToArchive": { "daysAfterModificationGreaterThan": 90 },
              "delete": { "daysAfterModificationGreaterThan": 365 }
            }
          },
          "filters": {
            "blobTypes": ["blockBlob", "appendBlob"],
            "prefixMatch": ["pp-export/"]
          }
        }
      }
    ]
  }'
```

### 7.4 Deploy Container Apps Environment and Job

```bash
CAE_SUBNET_ID=$(az network vnet subnet show \
  -g "$RG_NAME" --vnet-name "$VNET_NAME" -n snet-cae --query id -o tsv)

# Create Container Apps Environment with VNet integration
az containerapp env create \
  --resource-group "$RG_NAME" \
  --name "cae-ppgov-prod" \
  --location "$LOCATION" \
  --infrastructure-subnet-resource-id "$CAE_SUBNET_ID" \
  --internal-only true \
  --zone-redundant true \
  --logs-workspace-id "$LOG_WORKSPACE_ID"

# Create the scheduled Container App Job
az containerapp job create \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --environment "cae-ppgov-prod" \
  --trigger-type Schedule \
  --cron-expression "0 2 * * *" \
  --parallelism 1 \
  --replica-completion-count 1 \
  --replica-timeout 7200 \
  --replica-retry-limit 1 \
  --image "${ACR_NAME}.azurecr.io/pp-export:${IMAGE_TAG}" \
  --registry-server "${ACR_NAME}.azurecr.io" \
  --registry-identity "$IDENTITY_ID" \
  --mi-user-assigned "$IDENTITY_ID" \
  --cpu 2.0 \
  --memory 4Gi \
  --env-vars \
    "AZURE_CLIENT_ID=$IDENTITY_CLIENT" \
    "PP_EXPORT_STORAGE_ACCOUNT_NAME=$STORAGE_NAME" \
    "PP_EXPORT_STORAGE_CONTAINER_NAME=pp-export" \
    "PP_EXPORT_ENV_CONCURRENCY=15" \
    "PP_EXPORT_LOG_LEVEL=INFO" \
    "PP_EXPORT_OUTPUT_PREFIX=$(date +%Y-%m-%d)/"
```

### 7.5 Configure Diagnostic Settings

```bash
# Container App Environment diagnostics
CAE_ID=$(az containerapp env show -g "$RG_NAME" -n "cae-ppgov-prod" --query id -o tsv)

az monitor diagnostic-settings create \
  --name "cae-diagnostics" \
  --resource "$CAE_ID" \
  --workspace "$LOG_WORKSPACE_ID" \
  --logs '[
    {"category": "ContainerAppConsoleLogs", "enabled": true},
    {"category": "ContainerAppSystemLogs", "enabled": true}
  ]'

# Storage account diagnostics
az monitor diagnostic-settings create \
  --name "storage-diagnostics" \
  --resource "${STORAGE_ID}/blobServices/default" \
  --workspace "$LOG_WORKSPACE_ID" \
  --logs '[
    {"category": "StorageRead", "enabled": true},
    {"category": "StorageWrite", "enabled": true},
    {"category": "StorageDelete", "enabled": true}
  ]' \
  --metrics '[
    {"category": "Transaction", "enabled": true}
  ]'
```

---

## 8. Phase 6 — Configuration and Validation

### 8.1 Validate Permissions (Pre-flight Check)

Before the first scheduled run, perform a manual test:

```bash
# Trigger a manual job execution with limited scope
az containerapp job start \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod"

# Monitor the execution
az containerapp job execution list \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --output table

# Stream logs
az containerapp job logs show \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --follow
```

### 8.2 Expected Output

A successful run produces 33 CSV files in the blob container:

```
pp-export/
├── 2026-04-27/
│   ├── Environments.csv
│   ├── Apps.csv
│   ├── AppConnectorRefs.csv
│   ├── Flows.csv
│   ├── FlowTriggers.csv
│   ├── FlowActions.csv
│   ├── FlowConnectionRefs.csv
│   ├── Connectors.csv
│   ├── Connections.csv
│   ├── CopilotAgents.csv
│   ├── CopilotComponents.csv
│   ├── DlpPolicies.csv
│   ├── DlpConnectorRules.csv
│   ├── UsageAnalytics.csv
│   ├── AppPermissions.csv          (if --collect-permissions)
│   ├── FlowPermissions.csv         (if --collect-permissions)
│   ├── EnvironmentPermissions.csv   (if --collect-env-permissions)
│   ├── DesktopFlows.csv
│   ├── BusinessProcessFlows.csv
│   ├── PowerPagesSites.csv
│   ├── PowerPagesComponents.csv
│   ├── AiBuilderModels.csv
│   ├── Solutions.csv
│   ├── SolutionComponents.csv
│   ├── UserIdentities.csv          (if --resolve-users)
│   ├── FlowRunHistory.csv          (if --collect-flow-runs)
│   ├── CopilotTopics.csv           (if --collect-copilot-enhanced)
│   ├── CopilotKnowledgeSources.csv (if --collect-copilot-enhanced)
│   ├── RiskScores.csv              (if --risk-scoring) [stub]
│   ├── DlpCompliance.csv           (if --dlp-compliance) [stub]
│   ├── ArchiveCandidates.csv       (if --archive-scoring) [stub]
│   ├── OrphanedResources.csv       (if --orphan-detection) [stub]
│   ├── Errors.csv
│   └── _checkpoint.txt
```

### 8.3 Validate CSV Output

```bash
# List blobs to verify output
az storage blob list \
  --account-name "$STORAGE_NAME" \
  --container-name "pp-export" \
  --auth-mode login \
  --output table

# Download and inspect a CSV
az storage blob download \
  --account-name "$STORAGE_NAME" \
  --container-name "pp-export" \
  --name "2026-04-27/Environments.csv" \
  --file /tmp/Environments.csv \
  --auth-mode login

head -5 /tmp/Environments.csv
```

### 8.4 Tune Concurrency Settings

For large tenants (100+ environments), adjust these settings:

| Setting | Default | Large Tenant Recommendation | Notes |
|---------|---------|----------------------------|-------|
| `PP_EXPORT_ENV_CONCURRENCY` | 15 | 10 | Reduce to avoid 429 throttling |
| `PP_EXPORT_FLOW_DEF_CONCURRENCY` | 10 | 5 | Flow definitions are rate-limited |
| `PP_EXPORT_CONNECTION_DETAIL_CONCURRENCY` | 10 | 5 | Detail calls are expensive |
| `PP_EXPORT_MAX_CONNECTION_DETAIL_CALLS` | 200 | 100 | Cap Pass 2 calls per env |
| `PP_EXPORT_ENV_TIMEOUT_MINUTES` | 10 | 15 | Large envs need more time |
| `PP_EXPORT_HTTP_TIMEOUT_SECONDS` | 60 | 120 | Dataverse can be slow |

Update environment variables on the Container App Job:

```bash
az containerapp job update \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --set-env-vars \
    "PP_EXPORT_ENV_CONCURRENCY=10" \
    "PP_EXPORT_FLOW_DEF_CONCURRENCY=5" \
    "PP_EXPORT_ENV_TIMEOUT_MINUTES=15"
```

---

## 9. Phase 7 — Power BI Dashboard Setup

### 9.1 Create Power BI Service Principal

```bash
# Create a service principal for Power BI to read blob storage
PBI_APP_NAME="ppgov-powerbi-reader"

az ad app create --display-name "$PBI_APP_NAME"
PBI_APP_ID=$(az ad app list --display-name "$PBI_APP_NAME" --query '[0].appId' -o tsv)

az ad sp create --id "$PBI_APP_ID"
PBI_SP_OBJECT_ID=$(az ad sp show --id "$PBI_APP_ID" --query id -o tsv)

# Grant Storage Blob Data Reader (read-only!)
az role assignment create \
  --assignee-object-id "$PBI_SP_OBJECT_ID" \
  --assignee-principal-type ServicePrincipal \
  --role "Storage Blob Data Reader" \
  --scope "$STORAGE_ID"
```

### 9.2 Configure Power BI Data Source

1. Open Power BI Desktop
2. Get Data > Azure Blob Storage
3. Enter storage account URL: `https://${STORAGE_NAME}.blob.core.windows.net`
4. Authenticate with the Power BI service principal (organizational account)
5. Navigate to the `pp-export` container and select the latest date prefix
6. Use the Power Query M script from `powerbi/import_all_csvs.pq` to load all 33 CSV tables
7. Configure relationships per `powerbi/RELATIONSHIPS.md`

### 9.3 Publish to Power BI Service

1. Publish the report to a dedicated workspace (e.g., "Power Platform Governance")
2. Configure scheduled refresh using the service principal credentials
3. Set up Row-Level Security (RLS) if different teams should only see their environments
4. Share the workspace with the governance/compliance team

---

## 10. Phase 8 — Production Hardening

### 10.1 Alert Rules

```bash
# Alert: Job execution failed
az monitor metrics alert create \
  --resource-group "$RG_NAME" \
  --name "ppgov-job-failed" \
  --description "PP Governance export job failed" \
  --scopes "$CAE_ID" \
  --condition "count ContainerAppJobExecutionFailed > 0" \
  --window-size 1h \
  --evaluation-frequency 15m \
  --severity 1 \
  --action-group "/subscriptions/<sub-id>/resourceGroups/<rg>/providers/Microsoft.Insights/actionGroups/<ag-name>"
```

### 10.2 Enable Microsoft Defender

```bash
# Defender for Storage
az security pricing create --name StorageAccounts --tier Standard

# Defender for Containers
az security pricing create --name Containers --tier Standard

# Defender for Key Vault
az security pricing create --name KeyVaults --tier Standard
```

### 10.3 Configure Azure Policy

Apply the following Azure Policy initiatives to the resource group:

| Policy | Effect | Purpose |
|--------|--------|---------|
| Require encryption with CMK | Audit/Deny | Enforce CMK on storage |
| Require private endpoints | Audit/Deny | No public endpoints |
| Require NSG on subnets | Audit/Deny | Network security |
| Require diagnostic settings | DeployIfNotExists | Ensure logging |
| Require TLS 1.2 minimum | Deny | Transport security |
| Deny public IP addresses | Deny | No public exposure |

```bash
# Example: Assign built-in policy for storage encryption
az policy assignment create \
  --name "require-storage-cmk" \
  --scope "/subscriptions/<sub-id>/resourceGroups/$RG_NAME" \
  --policy "b5ec538c-daa0-4006-8596-35468b9148e8" \
  --params '{"effect": {"value": "Deny"}}'
```

### 10.4 Set Up Date-Based Output Prefix

For daily snapshots with automatic date-based organization, update the Container App Job to use a dynamic output prefix. Since Container App Jobs don't support dynamic env vars natively, use a wrapper script:

Create `scripts/run-with-date-prefix.sh`:
```bash
#!/bin/bash
export PP_EXPORT_OUTPUT_PREFIX="$(date -u +%Y-%m-%d)/"
exec python -m pp_export "$@"
```

Update Dockerfile entrypoint:
```dockerfile
COPY scripts/run-with-date-prefix.sh ./
ENTRYPOINT ["bash", "run-with-date-prefix.sh"]
```

---

## 11. GitLab CI/CD Pipeline

The project includes a `.gitlab-ci.yml` pipeline with three stages: **test**, **build**, and **deploy**.

### 11.1 Pipeline Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    GitLab CI/CD Pipeline                  │
│                                                           │
│  ┌──────────┐    ┌──────────────┐    ┌────────────────┐   │
│  │  TEST     │    │  BUILD       │    │  DEPLOY        │   │
│  │           │    │              │    │                │   │
│  │ lint      │───▶│ build-image  │───▶│ deploy-staging │   │
│  │ type-check│    │ (kaniko)     │    │ (manual gate)  │   │
│  │ unit-tests│    │              │    │                │   │
│  │           │    │ scan-image   │    │ deploy-prod    │   │
│  │           │    │ (trivy)      │    │ (manual gate)  │   │
│  └──────────┘    └──────────────┘    └────────────────┘   │
│                                                           │
│  Triggers: merge requests + pushes to default branch      │
└─────────────────────────────────────────────────────────┘
```

### 11.2 GitLab CI/CD Variables

Configure these in **Settings > CI/CD > Variables** (mask secrets):

| Variable | Type | Masked | Description |
|----------|------|--------|-------------|
| `AZURE_TENANT_ID` | Variable | No | Azure AD tenant ID |
| `AZURE_CLIENT_ID` | Variable | No | CI/CD service principal app (client) ID |
| `AZURE_CLIENT_SECRET` | Variable | **Yes** | Service principal client secret |
| `AZURE_SUBSCRIPTION_ID` | Variable | No | Target Azure subscription |
| `ACR_REGISTRY` | Variable | No | ACR login server (e.g., `crppgovprod.azurecr.io`) |
| `RESOURCE_GROUP` | Variable | No | Staging resource group name |
| `CONTAINER_APP_JOB_NAME` | Variable | No | Staging Container App Job name |
| `PROD_RESOURCE_GROUP` | Variable | No | Production resource group name |
| `PROD_CONTAINER_APP_JOB_NAME` | Variable | No | Production Container App Job name |

### 11.3 Create a CI/CD Service Principal

The pipeline needs a service principal with permissions to push images to ACR and update the Container App Job:

```bash
# Create the service principal
SP_NAME="gitlab-ppgov-cicd"

az ad sp create-for-rbac \
  --name "$SP_NAME" \
  --role Contributor \
  --scopes "/subscriptions/<subscription-id>/resourceGroups/$RG_NAME" \
  --json-auth

# Output contains appId, password, tenant — save to GitLab CI/CD variables
```

Grant AcrPush to the CI/CD service principal:

```bash
CICD_SP_ID=$(az ad sp list --display-name "$SP_NAME" --query '[0].id' -o tsv)
ACR_ID=$(az acr show -n "$ACR_NAME" --query id -o tsv)

az role assignment create \
  --assignee-object-id "$CICD_SP_ID" \
  --assignee-principal-type ServicePrincipal \
  --role AcrPush \
  --scope "$ACR_ID"
```

### 11.4 Pipeline Behavior

| Event | Stages Run | Deploy? |
|-------|-----------|---------|
| Merge request opened/updated | test | No |
| Push to default branch (main) | test, build | Manual gate |
| Manual trigger: deploy-staging | deploy | Deploys to staging + triggers test run |
| Manual trigger: deploy-production | deploy | Deploys to production (requires staging first) |

### 11.5 Docker Builds with Kaniko

The pipeline uses [kaniko](https://github.com/GoogleContainerTools/kaniko) instead of Docker-in-Docker for building images. This avoids privileged containers and works in standard GitLab runners.

The kaniko executor:
1. Authenticates to ACR using the CI/CD service principal credentials
2. Builds the multi-stage Dockerfile
3. Tags with both `$CI_COMMIT_SHORT_SHA` and `latest`
4. Pushes both tags
5. Uses layer caching via `--cache-repo` for faster rebuilds

### 11.6 Image Scanning

After the build, Trivy scans the pushed image for CRITICAL and HIGH CVEs. The scan is configured as `allow_failure: true` so it doesn't block deployment, but results are visible in the pipeline.

To make scanning a hard gate, change `allow_failure: false` in `.gitlab-ci.yml`.

### 11.7 GitLab Container Registry (Alternative)

If your GitLab instance has a built-in Container Registry, you can push to it instead of ACR and then mirror to ACR:

```yaml
# Alternative: push to GitLab registry
build-image:
  script:
    - /kaniko/executor
        --context "${CI_PROJECT_DIR}"
        --dockerfile "${CI_PROJECT_DIR}/Dockerfile"
        --destination "${CI_REGISTRY_IMAGE}:${CI_COMMIT_SHORT_SHA}"
        --destination "${CI_REGISTRY_IMAGE}:latest"
```

Then import into ACR:
```bash
az acr import \
  --name "$ACR_NAME" \
  --source "gitlab.example.com:5050/team/ppgov:latest" \
  --username "<gitlab-token-name>" \
  --password "<gitlab-deploy-token>"
```

---

## 12. Operations Runbook

### 11.1 Daily Operations

The export job runs automatically at 02:00 UTC daily. No daily operator action required.

**Automated monitoring checks:**
- Alert if job doesn't complete by 04:00 UTC
- Alert if Errors.csv contains more than 10 entries
- Alert if any environment reports timeout

### 11.2 Manual Job Trigger

```bash
# Trigger immediate execution
az containerapp job start \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod"

# Check execution status
az containerapp job execution list \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --output table

# View logs from latest execution
az containerapp job logs show \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --follow
```

### 11.3 Update Container Image

```bash
# Build new image
NEW_TAG="v1.1.0-$(git rev-parse --short HEAD)"
docker build -t "${ACR_NAME}.azurecr.io/pp-export:${NEW_TAG}" .
docker push "${ACR_NAME}.azurecr.io/pp-export:${NEW_TAG}"

# Update the job to use new image
az containerapp job update \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --image "${ACR_NAME}.azurecr.io/pp-export:${NEW_TAG}"

# Trigger a test run to validate
az containerapp job start \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod"
```

### 11.4 Rotate Credentials

The managed identity credentials are automatically rotated by Azure — no manual rotation needed.

If you ever use service principal credentials:
```bash
# Rotate client secret (if used)
az ad app credential reset --id "$APP_ID" --years 1
# Update in Key Vault
az keyvault secret set --vault-name "$KV_NAME" --name "pp-export-client-secret" --value "<new-secret>"
# Container App picks up new value from Key Vault reference automatically
```

### 11.5 Scale Resources

For larger tenants or faster exports:

```bash
# Increase CPU/memory
az containerapp job update \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --cpu 4.0 \
  --memory 8Gi

# Increase replica timeout for very large tenants
az containerapp job update \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --replica-timeout 14400   # 4 hours
```

---

## 12. Troubleshooting

### 12.1 Common Errors

| Symptom | Cause | Fix |
|---------|-------|-----|
| `"storage_account_name is required"` | Missing environment variable | Set `PP_EXPORT_STORAGE_ACCOUNT_NAME` |
| `"ClientAuthenticationError"` | Managed identity doesn't have required permissions | Check Section 4 — verify role assignments |
| `"HttpResponseError: (403) Forbidden"` on Dataverse | Managed identity lacks Dataverse permissions | Grant System Administrator or equivalent Dataverse security role |
| `"throttled_429"` in logs | API rate limiting | Reduce concurrency settings (Section 8.4) |
| `"env_timeout"` for specific environments | Environment has too many resources | Increase `PP_EXPORT_ENV_TIMEOUT_MINUTES` |
| `"copilot_no_bots"` for all environments | Dataverse URL not available or token issue | Check that environments have Dataverse linked; verify token audience |
| Container image pull fails | ACR registry not configured in job | Ensure `--registry-server` and `--registry-identity` are set |
| `"WinError 1450"` on Windows | Too many concurrent az CLI subprocesses | Use `--auth-mode cli` (serialized) or managed identity |
| Empty `UserIdentities.csv` | Known bug: owner IDs not accumulated | See ISSUES-ANALYSIS.md Issue #3 |

### 12.2 Debug Mode

For detailed troubleshooting, run with debug logging:

```bash
az containerapp job update \
  --resource-group "$RG_NAME" \
  --name "caj-ppgov-prod" \
  --set-env-vars "PP_EXPORT_LOG_LEVEL=DEBUG"

# Trigger and monitor
az containerapp job start -g "$RG_NAME" -n "caj-ppgov-prod"
az containerapp job logs show -g "$RG_NAME" -n "caj-ppgov-prod" --follow
```

> **Warning:** DEBUG level logs may contain internal hostnames and API URLs. Reset to INFO after debugging.

### 12.3 Local Testing Before Deployment

```bash
cd powerplatform-export

# Create virtual environment
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows

# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest -v

# Run locally with local storage backend
cp .env.example .env
# Edit .env: set PP_EXPORT_STORAGE_BACKEND=local

# Login to Azure
az login --tenant <your-tenant-id>

# Run export
python -m pp_export --storage-backend local --log-level DEBUG
```

---

## 13. Disaster Recovery

### 13.1 RTO/RPO Targets

| Component | RPO | RTO | Strategy |
|-----------|-----|-----|----------|
| Container Image | 0 (stored in ACR with geo-replication) | 15 min | Redeploy from ACR |
| CSV Output Data | 24 hours (daily export) | 1 hour | GRS replication |
| Infrastructure Config | 0 (Bicep in Git) | 30 min | Redeploy from IaC |
| Power BI Reports | 0 (in Power BI Service) | 15 min | Re-point data source |

### 13.2 Geo-Redundancy

| Resource | Redundancy | Configuration |
|----------|-----------|---------------|
| Storage Account | GRS | Automatic async replication to paired region |
| Container Registry | Geo-replication (Premium SKU) | Manual: `az acr replication create` |
| Key Vault | Automatic (within Azure region) | Paired region failover |
| Container App | Zone-redundant | Configured in CAE |

### 13.3 Recovery Procedure

If the primary region fails:

1. Create a new resource group in the paired region
2. Deploy infrastructure from Bicep templates (stored in Git)
3. Push container image to the new ACR (or use geo-replicated ACR)
4. Point storage account to the GRS secondary endpoint (read-only) or create new account
5. Update Power BI data source to new storage account
6. Trigger a manual export run to generate fresh data

---

## 14. Cost Estimation

### 14.1 Monthly Cost Breakdown (East US 2, April 2026 pricing)

| Resource | SKU | Estimated Monthly Cost |
|----------|-----|----------------------|
| Container App Job (2 vCPU, 4 GiB, ~1 hr/day) | Consumption | $15-25 |
| Storage Account (GRS, ~500 MB data, ~10K transactions) | Standard_GRS | $5-10 |
| Container Registry (Premium, 1 image) | Premium | $50 |
| Key Vault (1 key, ~100 operations/day) | Premium | $5 |
| Log Analytics (~500 MB/month ingestion) | PerGB2018 | $3-5 |
| Virtual Network + Private Endpoints (3 PEs) | Standard | $22-30 |
| Microsoft Defender (Storage + Containers + KV) | Standard | $30-50 |
| **Total** | | **$130-175/month** |

### 14.2 Cost Optimization

- **Container Registry:** Can use Standard SKU ($5/month) instead of Premium ($50/month) if geo-replication is not required — but Premium is needed for private endpoints
- **Container App Job:** Pay-per-execution model means costs scale linearly with runtime. Optimize concurrency settings to reduce run time
- **Log Analytics:** Reduce retention from 90 to 30 days to lower costs (balance with compliance requirements)
- **Dev/Staging:** Use Basic Container Registry, Standard_LRS storage, no private endpoints, and no Defender for non-production

---

## Appendix A — Complete Environment Variable Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AZURE_CLIENT_ID` | Yes (in Azure) | — | Managed identity client ID |
| `PP_EXPORT_STORAGE_BACKEND` | No | `azure` | `azure` or `local` |
| `PP_EXPORT_STORAGE_ACCOUNT_NAME` | Yes (if azure) | — | Storage account name |
| `PP_EXPORT_STORAGE_CONTAINER_NAME` | No | `pp-export` | Blob container name |
| `PP_EXPORT_ENV_CONCURRENCY` | No | `15` | Max parallel environments |
| `PP_EXPORT_FLOW_DEF_CONCURRENCY` | No | `10` | Max parallel flow definition fetches |
| `PP_EXPORT_CONNECTION_DETAIL_CONCURRENCY` | No | `10` | Max parallel connection detail calls |
| `PP_EXPORT_MAX_CONNECTION_DETAIL_CALLS` | No | `200` | Max detail calls per environment |
| `PP_EXPORT_ENV_TIMEOUT_MINUTES` | No | `10` | Per-environment timeout |
| `PP_EXPORT_HTTP_TIMEOUT_SECONDS` | No | `60` | HTTP request timeout |
| `PP_EXPORT_COLLECT_PERMISSIONS` | No | `false` | Collect app/flow permissions |
| `PP_EXPORT_COLLECT_COPILOT` | No | `true` | Collect Copilot agents |
| `PP_EXPORT_COLLECT_DESKTOP_FLOWS` | No | `true` | Collect desktop flows (RPA) |
| `PP_EXPORT_COLLECT_BPF` | No | `true` | Collect business process flows |
| `PP_EXPORT_COLLECT_POWER_PAGES` | No | `true` | Collect Power Pages sites |
| `PP_EXPORT_COLLECT_AI_BUILDER` | No | `true` | Collect AI Builder models |
| `PP_EXPORT_COLLECT_SOLUTIONS` | No | `true` | Collect Dataverse solutions |
| `PP_EXPORT_COLLECT_FLOW_RUNS` | No | `false` | Collect flow run history (slow) |
| `PP_EXPORT_COLLECT_COPILOT_ENHANCED` | No | `false` | Enhanced Copilot data (slow) |
| `PP_EXPORT_RESOLVE_USER_IDENTITIES` | No | `false` | Resolve users via Graph |
| `PP_EXPORT_OUTPUT_PREFIX` | No | `""` | Blob name prefix (e.g., `2026-04-27/`) |
| `PP_EXPORT_LOG_LEVEL` | No | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR` |

## Appendix B — CLI Flags Reference

```
python -m pp_export [OPTIONS]

Storage:
  --storage-backend {azure,local}     Storage backend (default: azure)
  --storage-account-name NAME         Azure Storage account name
  --storage-container-name NAME       Blob container name (default: pp-export)
  --local-output-dir DIR              Output dir for local backend
  --output-prefix PREFIX              Blob name prefix

Auth:
  --auth-mode {default,interactive,device,cli}  Credential type
  --auth-tenant-id ID                 AAD tenant ID

Collection:
  --collect-permissions               Collect app/flow permissions
  --collect-env-permissions           Collect environment role assignments
  --collect-flow-runs                 Collect flow run history
  --collect-copilot-enhanced          Enhanced Copilot data
  --resolve-users                     Resolve user identities via Graph
  --no-copilot                        Skip Copilot collection
  --no-desktop-flows                  Skip desktop flows
  --no-bpf                            Skip business process flows
  --no-power-pages                    Skip Power Pages
  --no-ai-builder                     Skip AI Builder
  --no-solutions                      Skip solutions

Analysis:
  --risk-scoring                      Compute risk scores
  --dlp-compliance                    Check DLP compliance
  --archive-scoring                   Score archivability
  --orphan-detection                  Detect orphaned owners

Output:
  --generate-docs                     Generate Markdown docs
  --generate-tmdl                     Generate Power BI TMDL

Umbrella:
  --governance                        Enable all analysis + output + users

General:
  --env-concurrency N                 Max parallel environments (default: 15)
  --log-level {DEBUG,INFO,WARNING,ERROR}
```
