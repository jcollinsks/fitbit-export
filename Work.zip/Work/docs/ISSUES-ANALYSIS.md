# Issues Analysis - Power Platform Enterprise Governance Report

**Date:** 2026-04-27
**Reviewer:** Claude Code (Opus 4.6)
**Scope:** Full codebase review of `powerplatform-export/` — Python source, Bicep infrastructure, Dockerfile, tests, configuration

---

## Critical Issues

### 1. Dockerfile Build Order Bug — Container Image is Broken
**File:** `powerplatform-export/Dockerfile:8`
**Severity:** CRITICAL — The Docker image will not run.

```dockerfile
COPY pyproject.toml ./
RUN pip install --no-cache-dir . && pip cache purge   # <-- src/ doesn't exist yet
COPY src/ ./src/                                       # <-- copied AFTER install
```

`pip install .` invokes `setuptools.build_meta`, which reads `[tool.setuptools.packages.find] where = ["src"]`. Since `src/` has not been copied yet, setuptools finds zero packages and installs an empty `pp-export` package with only the dependencies. The `COPY src/` afterwards places source files on disk, but they are not installed as a Python package. `python -m pp_export` then fails because the installed package has no `__main__.py`.

**Fix:**
```dockerfile
FROM python:3.12-slim AS base
WORKDIR /app
RUN groupadd -r appuser && useradd -r -g appuser -d /app appuser

# Install dependencies only (cached layer)
COPY pyproject.toml ./
RUN pip install --no-cache-dir --only-deps . 2>/dev/null || pip install --no-cache-dir aiohttp azure-identity azure-storage-blob pydantic-settings structlog tenacity

# Copy source and install the actual package
COPY src/ ./src/
RUN pip install --no-cache-dir . && pip cache purge

RUN chown -R appuser:appuser /app
USER appuser
ENTRYPOINT ["python", "-m", "pp_export"]
```

---

### 2. Container App Job Cannot Pull Images from ACR
**File:** `powerplatform-export/infra/modules/container-app-job.bicep:53`
**Severity:** CRITICAL — The scheduled job will fail at startup.

```bicep
registries: []   // Empty — no ACR authentication configured
```

The container app job references an image from the ACR (`${acr.outputs.loginServer}/${imageName}:${imageTag}`) but provides no registry credentials. The managed identity has AcrPull permissions granted, but the Container App Job configuration does not reference it.

**Fix:**
```bicep
registries: [
  {
    server: '${split(containerImage, '/')[0]}'
    identity: identityId
  }
]
```

---

### 3. User Identity Resolution is Dead Code
**File:** `powerplatform-export/src/pp_export/main.py:486-500`
**Severity:** CRITICAL — Feature advertised in README/CLI never produces output.

```python
resolve_result = await graph_users.collect_user_identities(
    client,
    set(),  # <-- Always empty! Owner IDs never accumulated.
    csv_manager.get("UserIdentities"),
    ...
)
```

The `resolve_user_identities` feature flag, the `--resolve-users` CLI flag, and the `--governance` umbrella all enable this codepath, but it always passes an empty `set()`. Owner IDs from apps, flows, copilot agents, and other collectors are never gathered. The `UserIdentities.csv` will always be empty.

**Fix:** Accumulate owner IDs during `_process_single_environment` and pass them to the post-collection analysis:

```python
# In _process_single_environment, collect owner IDs:
owner_ids: set[str] = set()
# ... after collecting apps, flows, etc., extract owner_id fields ...

# In _run_post_collection_analysis, receive and use the accumulated set:
resolve_result = await graph_users.collect_user_identities(
    client,
    accumulated_owner_ids,
    csv_manager.get("UserIdentities"),
    ...
)
```

---

## High-Severity Issues

### 4. asyncio.gather Silently Swallows Environment Processing Exceptions
**File:** `powerplatform-export/src/pp_export/main.py:192-195`
**Severity:** HIGH

```python
await asyncio.gather(
    *(process_environment(env) for env in environments),
    return_exceptions=True,   # <-- exceptions become return values, never logged
)
```

If `process_environment` raises an unhandled exception (beyond the try/except inside it), `return_exceptions=True` captures it as a return value but the return values are discarded. The export reports success even if every environment failed.

**Fix:** Either check the return values for exceptions, or use `return_exceptions=False` and wrap in appropriate error handling.

---

### 5. Connection URLs Not Updated After Pass 2
**File:** `powerplatform-export/src/pp_export/collectors/connectors.py:84-94`
**Severity:** HIGH — Pass 2 URL resolution has no effect on Connections CSV.

The Connections CSV is written at lines 85-89 (before Pass 2). Pass 2 (lines 92-94) updates `conn_base_urls` dict, but these updates are never reflected in the already-written CSV rows. Connections that needed Pass 2 will always have empty `base_url` in the output.

**Fix:** Either defer writing connection rows until after Pass 2, or update the already-written rows.

---

### 6. `_make_error` Receives Non-String Arguments
**File:** `powerplatform-export/src/pp_export/main.py:148`
**Severity:** MEDIUM

```python
errors.append(_make_error("", "dlp", "ApiError", dlp_result.error))
```

Several callers pass objects (like `ApiError` instances) as the `message` parameter. `_make_error` calls `message[:500]` which works on strings via slicing but would fail on non-string types if they don't support slicing. Currently this works by accident because most error types are strings, but it's fragile.

**Fix:** Cast `message` to `str()` inside `_make_error` before slicing.

---

### 7. `flush_all()` Flushes ALL CSV Buffers Per Environment
**File:** `powerplatform-export/src/pp_export/main.py:456`
**Severity:** MEDIUM — Performance and correctness concern.

```python
counts = await csv_manager.flush_all()
```

This is called inside `_process_single_environment` (per-environment, concurrent). `flush_all()` iterates ALL 33 registered buffers, not just the ones written to by this environment. Multiple concurrent environments may flush buffers that have no data, or flush another environment's pending data prematurely.

Since `CsvBuffer.flush()` resets the buffer after flushing, and `add_row()`/`flush()` share the same `StringIO`, concurrent access from different environments writing to the same buffer (e.g., `Environments`, `DlpPolicies`) could cause data races — rows from one env could end up in another env's flush.

**Fix:** Use per-environment buffer instances or flush only the buffers that were written to within the current environment.

---

### 8. Interactive/Device Auth Silently Falls Back to CLI
**File:** `powerplatform-export/src/pp_export/auth/credential_factory.py:35-41`
**Severity:** MEDIUM

```python
if mode in ("interactive", "device"):
    logger.warning("auth_mode_unavailable_falling_back_to_cli", requested=mode)
    return SerializedCliCredential()
```

Users who explicitly request `--auth-mode interactive` or `--auth-mode device` silently get CLI auth instead. This could fail if `az login` hasn't been run, with a confusing error message about CLI credentials rather than telling them interactive auth isn't supported.

---

### 9. Governance Flag Applied Twice
**File:** `powerplatform-export/src/pp_export/cli.py:253-263` and `main.py:86-97`
**Severity:** LOW — No functional impact but unclear ownership.

The `--governance` flag expands to individual flags in both `cli.py` (lines 253-263) and `main.py` (lines 86-97). The CLI expansion sets 9 overrides; the `main.py` expansion sets 7 (missing `collect_environment_permissions` and `resolve_user_identities`). This means the CLI does more than `main.py`, creating inconsistency if `governance=True` is set via environment variable rather than CLI flag.

---

### 10. No Pagination Limit Safety on Dataverse Queries
**File:** `powerplatform-export/src/pp_export/api/endpoints.py` (all Dataverse URLs)
**Severity:** MEDIUM — Could cause OOM on large tenants.

Dataverse queries like `bots`, `workflows`, `solutions`, `powerpagesites`, and `msdyn_aimodels` have no `$top` parameter. Combined with `get_all_pages(max_pages=100)`, a large enterprise tenant with thousands of objects could return massive result sets that exhaust container memory (4 GiB).

---

### 11. OData Filter Injection in Endpoint URLs
**File:** `powerplatform-export/src/pp_export/api/endpoints.py:43,47,59`
**Severity:** MEDIUM — Potential injection if env/connector/connection names contain special characters.

```python
def list_connectors_url(env_name: str) -> str:
    return f"...?$filter=environment eq '{env_name}'"
```

Environment names, connector names, and connection names are interpolated directly into OData `$filter` expressions with single-quote delimiters but no escaping. If a name contains a single quote, the filter expression breaks. While these values come from the Power Platform API (not user input), a maliciously-named environment could alter the query semantics.

---

### 12. graph_users.py Uses `return_exceptions=False`
**File:** `powerplatform-export/src/pp_export/collectors/graph_users.py:59`
**Severity:** MEDIUM

```python
await asyncio.gather(*(resolve_one(uid) for uid in cleaned), return_exceptions=False)
```

Unlike the main orchestrator, this uses `return_exceptions=False`, which means if ANY single user resolution throws an unexpected exception (e.g., `aiohttp.ClientError` bypassing the result handling), the entire user resolution batch is aborted and the exception propagates.

---

## Infrastructure Issues

### 13. No Zone Redundancy
**File:** `container-app-job.bicep:29`

```bicep
zoneRedundant: false
```

For a Fortune 100 deployment, the Container Apps environment should be zone-redundant.

### 14. Standard_LRS Storage — No Geo-Redundancy
**File:** `storage.bicep:16`

```bicep
sku: { name: 'Standard_LRS' }
```

LRS provides no protection against datacenter failure. Enterprise deployments should use `Standard_GRS` or `Standard_RAGRS`.

### 15. No Network Isolation
**Files:** All Bicep modules

No VNet integration, private endpoints, service endpoints, or NSGs are configured. All resources are publicly accessible. This fails most Fortune 100 security reviews.

### 16. No Diagnostic Logging
**Files:** All Bicep modules

No `diagnosticSettings` resources for storage account access logs, container app logs, or ACR audit logs. Required for SOC 2, ISO 27001, and most enterprise compliance frameworks.

### 17. No Customer-Managed Keys (CMK)
**File:** `storage.bicep`

Blob storage relies on Microsoft-managed encryption keys. Many Fortune 100 companies require CMK via Azure Key Vault.

### 18. Container App Job Replica Timeout Too High
**File:** `container-app-job.bicep:52`

```bicep
replicaTimeout: 86400  // 24 hours
```

A 24-hour timeout with no health checks means a hung job consumes resources for a full day before failing. For a scheduled daily job, this should be capped at 2-4 hours.

---

## Code Quality Issues

### 19. Missing `__init__.py` Exports
Multiple `__init__.py` files contain only docstrings with no exports, making the package structure opaque.

### 20. No Lock File
**File:** `powerplatform-export/pyproject.toml`

No `requirements.txt` or lock file pins exact dependency versions. `aiohttp>=3.9,<4` could resolve to different versions across builds, causing non-reproducible deployments.

### 21. Test Coverage Gaps
- No integration tests (empty `tests/integration/` directory)
- No tests for `main.py` orchestrator logic
- No tests for `cli.py` argument parsing
- No tests for `BlobWriter`, `FileWriter`, `CsvBuffer`, or `BlobCsvManager`
- No tests for any collector functions (only parsers are tested)

### 22. Analysis Features Are Stubs
The following features are advertised and have CSV schemas/flags but no implementation:
- Risk scoring (`run_risk_scoring`)
- DLP compliance checking (`run_dlp_compliance`)
- Archive candidate scoring (`run_archive_scoring`)
- Orphan detection (`run_orphan_detection`)
- Markdown documentation generation (`generate_markdown_docs`)
- TMDL generation (`generate_tmdl`)

The `_run_post_collection_analysis` function only implements user identity resolution (which is itself broken per Issue #3).

---

## Summary

| Severity | Count | Key Items |
|----------|-------|-----------|
| CRITICAL | 3 | Dockerfile broken, ACR auth missing, user resolution dead code |
| HIGH | 2 | Silent exception swallowing, Pass 2 URLs not written |
| MEDIUM | 7 | Auth fallback, flush_all races, OData injection, no pagination limits |
| LOW / Quality | 6+ | Missing lock file, no integration tests, stub features, governance duplication |
| Infrastructure | 6 | No VNet, no geo-redundancy, no CMK, no diagnostics, no zone redundancy |
