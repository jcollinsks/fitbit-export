# Architecture

## System Overview

The Power Platform Enterprise Governance Report follows a pipeline architecture with four layers:

```
Collection → Storage → Analysis → Output
```

### Collection Layer
Orchestrates API calls across all Power Platform data sources with rate limiting, retry logic, and incremental sync support. Each collector module handles one resource type and normalizes data into a common format.

### Storage Layer
PostgreSQL with a star-schema dimensional model. Fact tables are date-partitioned for efficient historical queries. JSON columns store PowerDocu-level detail (flow definitions, control trees, agent topics) alongside structured metadata.

### Analysis Layer
Operates on stored data to compute risk scores, DLP compliance violations, archive candidates, and cross-environment drift. Analysis runs after each collection cycle.

### Output Layer
Generates documentation and reports from analyzed data. Supports multiple output formats (Power BI, Markdown, JSON, CSV) and can push to Azure Data Lake.

## Data Flow

1. **Scheduler** triggers collection cycle (configurable: hourly, daily, on-demand)
2. **Environment Collector** discovers all environments, establishes scope
3. **Resource Collectors** run in parallel per environment (with rate limiting)
4. **Solution Exporter** exports solutions for PowerDocu-level parsing
5. **Parsers** extract detail from exported definitions
6. **Storage** upserts current snapshot, archives previous
7. **Analyzers** compute scores and detect violations
8. **Generators** produce output artifacts
9. **Power BI** refreshes from PostgreSQL (DirectQuery or Import)

## Authentication

Single Entra ID app registration with certificate-based auth. Service principal granted:
- Power Platform Service Admin role
- Microsoft Graph application permissions
- Dataverse System Administrator per environment (via application user)

## Scaling Considerations

- Parallel environment processing with configurable concurrency
- Per-API rate limiters with token bucket algorithm
- Batch requests where APIs support it (Graph, Dataverse)
- Delta queries for incremental sync (Graph)
- Pagination handling for all APIs
- Connection pooling for database
