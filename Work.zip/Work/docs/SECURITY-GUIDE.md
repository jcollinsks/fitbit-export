# Security Guide — Power Platform Enterprise Governance Report

**Target Audience:** Security architects, cloud security engineers, and compliance officers at Fortune 100 organizations.
**Platform:** Microsoft Azure
**Last Updated:** 2026-04-27

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Threat Model](#2-threat-model)
3. [Identity and Access Management](#3-identity-and-access-management)
4. [Network Security](#4-network-security)
5. [Data Protection](#5-data-protection)
6. [Secret Management](#6-secret-management)
7. [Container Security](#7-container-security)
8. [API Security](#8-api-security)
9. [Logging, Monitoring, and Alerting](#9-logging-monitoring-and-alerting)
10. [Compliance Mapping](#10-compliance-mapping)
11. [Incident Response](#11-incident-response)
12. [Hardening Checklist](#12-hardening-checklist)

---

## 1. Executive Summary

The Power Platform Enterprise Governance Report is a Python-based data exporter that reads metadata from Microsoft Power Platform APIs (Power Apps, Power Automate, Copilot Studio, Dataverse, DLP policies) and writes structured CSV files to Azure Blob Storage. It runs as a scheduled Azure Container App Job.

**Security-critical characteristics:**
- **Read-only** against Power Platform APIs — it does not modify tenant resources
- **High-privilege** — requires Power Platform Admin and Microsoft Graph read permissions across all environments
- **Sensitive output** — CSV files contain a complete inventory of all apps, flows, connections, user identities, permissions, and DLP policies. This data is a roadmap to the organization's entire Power Platform attack surface
- **Scheduled execution** — runs daily on a CRON schedule with no interactive operator

**Primary risks:**
1. Exfiltration of governance data (the output CSVs)
2. Credential compromise of the managed identity (grants tenant-wide read access)
3. Supply chain compromise of Python dependencies
4. Unauthorized access to the export infrastructure

---

## 2. Threat Model

### 2.1 Trust Boundaries

```
[External Internet]
        |
   [Azure VNet] ─── Trust Boundary 1
        |
   [Container App Job]
        |── outbound to Power Platform APIs (*.powerapps.com, *.flow.microsoft.com, etc.)
        |── outbound to Azure AD (login.microsoftonline.com)
        |── outbound to Microsoft Graph (graph.microsoft.com)
        |── internal to Azure Blob Storage
        |
   [Azure Blob Storage] ─── Trust Boundary 2
        |
   [Power BI / Analysts]
```

### 2.2 STRIDE Analysis

| Threat | Category | Risk | Mitigation |
|--------|----------|------|------------|
| Attacker reads governance CSV data | Information Disclosure | **CRITICAL** | Private endpoints, CMK encryption, RBAC, access reviews |
| Managed identity token stolen | Elevation of Privilege | **CRITICAL** | Conditional Access, token lifetime limits, workload identity federation |
| Malicious dependency injected | Tampering | **HIGH** | Pinned dependencies, vulnerability scanning, signed images |
| API responses contain malicious payloads | Spoofing | **MEDIUM** | TLS verification, response schema validation |
| Export job overloaded by API throttling | Denial of Service | **MEDIUM** | Retry budgets, circuit breakers, timeout enforcement |
| Logs contain PII or secrets | Information Disclosure | **MEDIUM** | Structured logging with field filtering, log retention policies |

### 2.3 Data Classification

| Data Category | Classification | Examples |
|---------------|---------------|----------|
| User identities | **PII / Confidential** | display names, email addresses, UPNs, job titles, departments, sign-in activity |
| Connection details | **Confidential** | connection URLs, base URLs (may reveal internal hostnames and database names) |
| DLP policies | **Internal** | policy definitions, connector classifications |
| Flow definitions | **Internal** | trigger URLs, action endpoints, connection references |
| Environment inventory | **Internal** | environment names, org URLs, tenant IDs, capacity data |
| Copilot agent config | **Internal** | authentication modes, access control policies, knowledge sources |

---

## 3. Identity and Access Management

### 3.1 Managed Identity Configuration

The application uses a **User-Assigned Managed Identity** (UAMI). This is the correct choice for a scheduled workload — it survives resource recreation and can be pre-configured with permissions.

**Required Azure AD App Registrations / Permissions:**

| API Surface | Permission | Type | Justification |
|-------------|-----------|------|---------------|
| Power Platform Admin (BAP API) | `Environment.Read.All` | Application | List environments, DLP policies, analytics |
| Power Apps API | `Apps.Read.All` | Application | List apps, connectors, connections |
| Power Automate API | `Flows.Read.All` | Application | List flows, flow definitions, flow runs |
| Dataverse (per-environment) | `user_impersonation` | Application | Copilot agents, desktop flows, BPFs, solutions, Power Pages, AI Builder |
| Microsoft Graph | `User.Read.All`, `AuditLog.Read.All` | Application | User identity resolution, sign-in activity |
| Azure Storage | Storage Blob Data Contributor (RBAC) | IAM Role | Write CSV output |
| Azure Container Registry | AcrPull (RBAC) | IAM Role | Pull container image |

**Hardening recommendations:**

1. **Principle of Least Privilege**: The managed identity should have ONLY the permissions listed above. Conduct quarterly access reviews.

2. **Conditional Access for Workload Identities**: Apply a Conditional Access policy to the managed identity:
   - Restrict token issuance to the Container App's IP range
   - Require compliant network location
   - Block token use from unexpected geographies

3. **Token Lifetime**: Configure short-lived tokens (1 hour max) via Azure AD token lifetime policies for the managed identity's service principal.

4. **No Shared Identities**: This managed identity must not be reused for any other workload. One identity per workload.

### 3.2 RBAC for Blob Storage Access

```
Storage Account
├── Storage Blob Data Contributor → Managed Identity (export job)
├── Storage Blob Data Reader → Power BI Service Principal (read-only)
├── Storage Account Contributor → DevOps pipeline (infrastructure only)
└── No other assignments
```

**Critical:** Remove `Storage Account Key` access entirely. Set `allowSharedKeyAccess: false` on the storage account to enforce Azure AD-only authentication:

```bicep
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  properties: {
    allowSharedKeyAccess: false   // Force AAD-only auth
    // ...
  }
}
```

### 3.3 Administrative Access

| Role | Scope | Principals |
|------|-------|------------|
| Resource Group Owner | RG level | Cloud Platform team (PIM-activated, time-limited) |
| Container App Contributor | Container App | DevOps pipeline SP only |
| Key Vault Secrets Officer | Key Vault | Break-glass emergency access (PIM) |
| Reader | RG level | Security/compliance auditors |

All human administrative access must use **Privileged Identity Management (PIM)** with:
- Just-in-time activation
- Maximum 8-hour activation window
- MFA required for activation
- Approval workflow for Owner/Contributor roles
- Access reviews every 90 days

---

## 4. Network Security

### 4.1 Current State (NOT Enterprise-Ready)

The current Bicep templates deploy all resources with public endpoints and no network isolation. **This configuration will fail security review at any Fortune 100 company.**

### 4.2 Target Architecture

```
                                   ┌──────────────────────────────┐
                                   │        Azure VNet            │
                                   │    10.0.0.0/16               │
                                   │                              │
                                   │  ┌─────────────────────┐     │
                                   │  │ Container App Subnet │     │
                                   │  │ 10.0.1.0/24          │     │
                                   │  │                       │     │
                                   │  │  [Container App Job]  │     │
                                   │  └───────┬───────────────┘     │
                                   │          │                     │
                                   │  ┌───────▼───────────────┐     │
                                   │  │ Private Endpoint       │     │
                                   │  │ Subnet 10.0.2.0/24    │     │
                                   │  │                        │     │
                                   │  │  PE: Storage Account   │     │
                                   │  │  PE: Container Registry│     │
                                   │  │  PE: Key Vault         │     │
                                   │  └────────────────────────┘     │
                                   │                              │
                                   │  ┌────────────────────────┐     │
                                   │  │ NSG Rules              │     │
                                   │  │ Inbound: DENY ALL      │     │
                                   │  │ Outbound:              │     │
                                   │  │  - HTTPS to MS APIs    │     │
                                   │  │  - HTTPS to AAD        │     │
                                   │  │  - Private Endpoints   │     │
                                   │  │  - DENY ALL else       │     │
                                   │  └────────────────────────┘     │
                                   └──────────────────────────────┘
```

### 4.3 Required Network Controls

**4.3.1 Virtual Network Integration**

Deploy the Container Apps environment with VNet integration:

```bicep
resource containerAppEnvironment 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: '${environmentName}-env'
  location: location
  properties: {
    zoneRedundant: true
    vnetConfiguration: {
      infrastructureSubnetId: containerAppSubnet.id
      internal: true   // No public ingress
    }
  }
}
```

**4.3.2 Private Endpoints**

All data-plane access to Azure services must use private endpoints:

| Service | Private Endpoint DNS Zone |
|---------|--------------------------|
| Storage Account (blob) | `privatelink.blob.core.windows.net` |
| Container Registry | `privatelink.azurecr.io` |
| Key Vault | `privatelink.vaultcore.azure.net` |

```bicep
resource storagePe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: '${storageAccountName}-pe'
  location: location
  properties: {
    subnet: { id: privateEndpointSubnet.id }
    privateLinkServiceConnections: [
      {
        name: 'storage-connection'
        properties: {
          privateLinkServiceId: storageAccount.id
          groupIds: ['blob']
        }
      }
    ]
  }
}
```

**4.3.3 Storage Account Firewall**

```bicep
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  properties: {
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'None'
      virtualNetworkRules: [
        { id: containerAppSubnet.id }
      ]
      ipRules: []   // No public IP access
    }
    publicNetworkAccess: 'Disabled'
  }
}
```

**4.3.4 NSG Rules**

```
Outbound Allow (Container App Subnet):
  1. HTTPS (443) to AzureActiveDirectory service tag
  2. HTTPS (443) to Internet (Power Platform APIs — cannot use service tags)
  3. HTTPS (443) to VirtualNetwork (private endpoints)

Outbound Deny:
  4. All other traffic DENY

Inbound:
  1. All traffic DENY (no inbound needed)
```

**4.3.5 DNS Configuration**

Configure Azure Private DNS zones for all private endpoints and link them to the VNet so that the container resolves `*.blob.core.windows.net` to private IP addresses.

---

## 5. Data Protection

### 5.1 Encryption at Rest

**Current:** Microsoft-managed keys (MMK) — default.
**Required:** Customer-Managed Keys (CMK) via Azure Key Vault.

```bicep
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  properties: {
    encryption: {
      keySource: 'Microsoft.Keyvault'
      keyvaultproperties: {
        keyname: keyVaultKey.name
        keyvaulturi: keyVault.properties.vaultUri
        keyversion: ''   // Auto-rotate
      }
      services: {
        blob: { enabled: true, keyType: 'Account' }
      }
    }
  }
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${managedIdentity.id}': {} }
  }
}
```

**Key Vault configuration:**
- Enable soft delete (90 days) and purge protection
- Key type: RSA 2048 or higher
- Key rotation policy: automatic, every 90 days
- Access: Key Vault Crypto Officer role (PIM-activated) for key management

### 5.2 Encryption in Transit

- **Storage:** Already enforced (`supportsHttpsTrafficOnly: true`, `minimumTlsVersion: 'TLS1_2'`)
- **API calls:** All Power Platform and Graph API calls use HTTPS (hardcoded in endpoint URLs)
- **Container Registry:** HTTPS-only by default

**Additional hardening:**
- Set `minimumTlsVersion: 'TLS1_3'` when available
- Verify `aiohttp` SSL certificate validation is not disabled (confirmed: default `ssl=None` in `aiohttp.ClientSession` uses system CA bundle)

### 5.3 Data Retention and Lifecycle

Implement blob lifecycle management to automatically delete or archive old export data:

```bicep
resource lifecyclePolicy 'Microsoft.Storage/storageAccounts/managementPolicies@2023-01-01' = {
  parent: storageAccount
  name: 'default'
  properties: {
    policy: {
      rules: [
        {
          name: 'archive-old-exports'
          type: 'Lifecycle'
          definition: {
            actions: {
              baseBlob: {
                tierToCool: { daysAfterModificationGreaterThan: 30 }
                tierToArchive: { daysAfterModificationGreaterThan: 90 }
                delete: { daysAfterModificationGreaterThan: 365 }
              }
            }
            filters: {
              blobTypes: ['blockBlob', 'appendBlob']
              prefixMatch: ['pp-export/']
            }
          }
        }
      ]
    }
  }
}
```

### 5.4 PII Handling

The `UserIdentities.csv` contains PII (names, emails, job titles, sign-in timestamps). Additional controls:

1. **Data minimization:** Only enable `--resolve-users` when user identity data is explicitly required for the governance report. Default is `false`.
2. **Access control:** Consider writing PII-containing CSVs to a separate blob container with stricter RBAC (e.g., only the compliance team's Power BI service principal gets reader access).
3. **Legal basis:** Ensure HR/Legal approval before collecting sign-in activity data (`signInActivity` from Microsoft Graph). This data is subject to employee monitoring regulations in many jurisdictions (GDPR Art. 6, CCPA, local labor laws).
4. **Retention:** PII data should have a shorter retention period than non-PII governance data (e.g., 90 days vs. 365 days).

### 5.5 Blob Immutability

For audit/compliance, enable immutable storage with a legal hold or time-based retention policy:

```bicep
resource container 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  properties: {
    publicAccess: 'None'
    immutableStorageWithVersioning: {
      enabled: true
    }
  }
}
```

---

## 6. Secret Management

### 6.1 Current State

The application uses `DefaultAzureCredential` / managed identity, which means **no secrets are stored in configuration**. This is the correct approach.

### 6.2 Risks to Mitigate

1. **`.env` file with credentials committed to source control:**
   - The `.env.example` file contains commented-out `AZURE_CLIENT_SECRET` placeholder
   - **Mitigation:** Add `.env` to `.gitignore` (already in `.dockerignore`). Run `git-secrets` or `gitleaks` in CI to prevent credential leaks.

2. **Environment variables in Container App Job:**
   - `AZURE_CLIENT_ID` is set as a plain-text environment variable in the Bicep template
   - This is acceptable because it's a client ID (not a secret), and the managed identity is bound to the container — the client ID alone cannot authenticate
   - **Do NOT add `AZURE_CLIENT_SECRET` as an environment variable.** If service principal auth is ever needed, use Azure Key Vault references.

3. **Logs leaking tokens:**
   - The `token_manager.py` logs `token_acquired` events but does not log the token value. **Confirmed safe.**
   - The `http_client.py` sets `Authorization: Bearer {token}` in headers. If debug HTTP logging is enabled (e.g., `aiohttp` debug mode), the full Authorization header could be logged.
   - **Mitigation:** Never set `aiohttp` logging to DEBUG in production. Add a log filter to redact Authorization headers if verbose HTTP logging is needed.

### 6.3 Azure Key Vault Integration (if needed)

If the deployment ever requires service principal credentials (e.g., for cross-tenant access):

```bicep
resource containerAppJob 'Microsoft.App/jobs@2023-05-01' = {
  properties: {
    template: {
      containers: [{
        env: [
          {
            name: 'AZURE_CLIENT_SECRET'
            secretRef: 'client-secret'   // Reference, not value
          }
        ]
      }]
    }
    configuration: {
      secrets: [
        {
          name: 'client-secret'
          keyVaultUrl: '${keyVault.properties.vaultUri}secrets/pp-export-client-secret'
          identity: identityId
        }
      ]
    }
  }
}
```

---

## 7. Container Security

### 7.1 Image Hardening

**Current Dockerfile analysis:**

| Control | Status | Notes |
|---------|--------|-------|
| Non-root user | Present | `appuser` created and used |
| Slim base image | Present | `python:3.12-slim` |
| No unnecessary packages | Present | Only pip packages installed |
| Multi-stage build | Missing | Single stage; build tools remain in final image |
| Pinned base image digest | Missing | Uses tag `3.12-slim`, not SHA digest |
| Health check | Missing | No `HEALTHCHECK` instruction |
| Read-only filesystem | Missing | Not enforced at container level |

**Recommended Dockerfile:**

```dockerfile
# Build stage
FROM python:3.12-slim AS builder
WORKDIR /build
COPY pyproject.toml ./
COPY src/ ./src/
RUN pip install --no-cache-dir --prefix=/install .

# Runtime stage
FROM python:3.12-slim@sha256:<pin-to-specific-digest>
WORKDIR /app

RUN groupadd -r appuser && useradd -r -g appuser -d /app appuser

COPY --from=builder /install /usr/local
COPY src/ ./src/

RUN chown -R appuser:appuser /app
USER appuser

# Health check (for monitoring — Container App Jobs don't use HTTP probes,
# but this documents expected behavior)
HEALTHCHECK --interval=60s --timeout=5s --retries=3 \
  CMD python -c "import pp_export; print('ok')" || exit 1

ENTRYPOINT ["python", "-m", "pp_export"]
```

### 7.2 Image Scanning

Integrate container image scanning into the CI/CD pipeline:

1. **Build-time:** Run `trivy image` or `grype` scan as a CI gate. Fail on CRITICAL/HIGH CVEs.
2. **Registry-time:** Enable Azure Defender for Container Registries (Microsoft Defender for Cloud).
3. **Runtime:** Enable Azure Defender for Containers on the subscription.

### 7.3 Container Runtime Security

Configure the Container App Job with security constraints:

```bicep
resource containerAppJob 'Microsoft.App/jobs@2023-05-01' = {
  properties: {
    template: {
      containers: [{
        // ... existing config ...
        volumeMounts: []   // No host mounts
      }]
    }
    configuration: {
      // Restrict egress (when VNet-integrated)
      // No volume mounts
      // No privileged mode (default in Container Apps)
    }
  }
}
```

### 7.4 Supply Chain Security

1. **Pin all dependency versions** with a lock file (`pip freeze > requirements.txt` or use `pip-tools`).
2. **Enable Dependabot** or **Renovate** for automated dependency updates with security advisory integration.
3. **Sign container images** using Notation (Notary v2) and verify signatures at deployment.
4. **SBOM generation:** Generate Software Bill of Materials with `syft` or `cyclonedx-bom` during CI.

---

## 8. API Security

### 8.1 Token Scoping

The `TokenManager` manages tokens for 5+ audiences. Each token should be scoped to the minimum required:

| Audience Key | Scope | Used For |
|-------------|-------|----------|
| `pp` | `https://service.powerapps.com/.default` | Apps, connectors, connections |
| `flow` | `https://service.flow.microsoft.com/.default` | Flows, flow definitions, flow runs |
| `bap` | `https://api.bap.microsoft.com/.default` | Environments, DLP policies |
| `admin` | `https://api.powerplatform.com/.default` | Usage analytics |
| `graph` | `https://graph.microsoft.com/.default` | User identity resolution |
| `dataverse:*` | Dynamic per org URL | Copilot, desktop flows, BPFs, solutions, Power Pages, AI Builder |

**Recommendation:** When using application permissions (service principal), the `.default` scope grants all consented permissions. Ensure the app registration has ONLY the minimum required API permissions and that admin consent is granted only for documented permissions.

### 8.2 Rate Limiting and Abuse Prevention

The application implements retry logic for HTTP 429 (throttled) responses:

- **429 retries:** Max 5, with exponential backoff starting at 30 seconds
- **5xx retries:** Max 5, with linear backoff starting at 5 seconds
- **401 retries:** Max 2, with token refresh

**Additional recommendations:**

1. **Circuit breaker:** If >50% of requests to an API surface fail within a 5-minute window, pause requests to that surface for 60 seconds before retrying. The current implementation retries per-request but has no aggregate circuit breaker.

2. **Request budget:** Set a maximum total API call count per export run (e.g., 50,000 calls). If exceeded, the job should complete with a warning rather than continuing to hammer APIs.

3. **Respect `Retry-After` headers exactly.** The current implementation uses `max(retry_after, base_backoff * 2^attempt)`, which may wait longer than the API suggests. This is conservative and acceptable.

### 8.3 Input Validation on API Responses

The application trusts API responses and extracts fields with `.get()` calls. While Power Platform APIs are Microsoft-managed and trustworthy, defensive coding should:

1. **Validate URL schemes** before constructing Dataverse endpoint URLs from `org_url`:
   ```python
   if not org_url.startswith("https://"):
       raise ValueError(f"Invalid org URL scheme: {org_url}")
   ```

2. **Sanitize OData filter values** to prevent injection:
   ```python
   def odata_escape(value: str) -> str:
       return value.replace("'", "''")
   ```

3. **Limit response size** — set `aiohttp.ClientSession` with `read_bufsize` limits to prevent memory exhaustion from unexpectedly large responses.

---

## 9. Logging, Monitoring, and Alerting

### 9.1 Current Logging

The application uses `structlog` with JSON output to stderr. Log entries include:
- ISO timestamps
- Log level
- Service name context
- Structured key-value pairs (environment names, counts, durations)

**What's logged correctly:**
- Token acquisition events (without token values)
- API call failures with status codes and URLs
- Per-environment processing start/complete with timing
- Error records with collector name and error type

**What should NOT be logged (verify):**
- User email addresses (check `_parse_user` output in debug logs)
- Connection URLs containing internal hostnames
- Full API response bodies (currently limited to 200 chars in `non_fatal_response`)

### 9.2 Azure Monitor Integration

Deploy diagnostic settings for all resources:

```bicep
resource storageDiagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'storage-diagnostics'
  scope: storageAccount::blobServices
  properties: {
    workspaceId: logAnalyticsWorkspace.id
    logs: [
      { category: 'StorageRead', enabled: true, retentionPolicy: { days: 90, enabled: true } }
      { category: 'StorageWrite', enabled: true, retentionPolicy: { days: 90, enabled: true } }
      { category: 'StorageDelete', enabled: true, retentionPolicy: { days: 90, enabled: true } }
    ]
    metrics: [
      { category: 'Transaction', enabled: true, retentionPolicy: { days: 90, enabled: true } }
    ]
  }
}

resource containerAppDiagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'container-app-diagnostics'
  scope: containerAppEnvironment
  properties: {
    workspaceId: logAnalyticsWorkspace.id
    logs: [
      { category: 'ContainerAppConsoleLogs', enabled: true }
      { category: 'ContainerAppSystemLogs', enabled: true }
    ]
  }
}
```

### 9.3 Alerting Rules

| Alert | Condition | Severity | Action |
|-------|-----------|----------|--------|
| Export job failed | Container App Job execution status != Succeeded | Sev 1 | Page on-call, auto-create incident |
| Export job exceeded 2 hours | Job duration > 7200s | Sev 2 | Notify team channel |
| Storage account anonymous access attempted | StorageRead with anonymous caller | Sev 1 | Page security team |
| Managed identity used from unexpected IP | Sign-in log with unexpected IP | Sev 1 | Page security team, disable identity |
| High 429 rate (>20% of requests throttled) | Custom metric from structlog | Sev 3 | Notify team, review concurrency settings |
| No export in 48 hours | Custom heartbeat check | Sev 2 | Notify team, check CRON schedule |

### 9.4 Log Retention

| Log Type | Retention | Reason |
|----------|-----------|--------|
| Application logs (structlog) | 90 days in Log Analytics, 1 year in archive | Troubleshooting + audit |
| Storage access logs | 90 days hot, 1 year archive | Compliance (SOC 2, ISO 27001) |
| Azure AD sign-in logs | Per AAD license (max 30 days free) | Security investigation |
| Container App system logs | 90 days | Infrastructure troubleshooting |

---

## 10. Compliance Mapping

### 10.1 SOC 2 Type II

| Trust Service Criteria | Control | Implementation |
|----------------------|---------|----------------|
| CC6.1 — Logical access | RBAC + managed identity | Section 3 |
| CC6.2 — Prior to issuing credentials | PIM + access reviews | Section 3.3 |
| CC6.3 — Registration/authorization | App registration with admin consent | Section 3.1 |
| CC6.6 — Restrict access to externally | Private endpoints + NSGs | Section 4 |
| CC6.7 — Restrict data transmission | TLS 1.2+ on all channels | Section 5.2 |
| CC7.1 — Detection/monitoring | Azure Monitor + alerts | Section 9 |
| CC7.2 — Anomaly detection | Sign-in anomaly alerts | Section 9.3 |
| CC8.1 — Change management | CI/CD pipeline with image scanning | Section 7 |

### 10.2 ISO 27001:2022

| Control | Annex A Reference | Implementation |
|---------|-------------------|----------------|
| Access control | A.5.15-A.5.18 | Managed identity, RBAC, PIM |
| Cryptography | A.8.24 | CMK encryption, TLS 1.2+ |
| Network security | A.8.20-A.8.22 | VNet, private endpoints, NSGs |
| Logging and monitoring | A.8.15-A.8.16 | Diagnostic settings, Log Analytics |
| Secure development | A.8.25-A.8.27 | Image scanning, dependency pinning, SBOM |
| Data classification | A.5.12-A.5.13 | Section 2.3 data classification table |

### 10.3 NIST 800-53 (FedRAMP)

| Control Family | Key Controls | Implementation |
|---------------|-------------|----------------|
| AC (Access Control) | AC-2, AC-3, AC-6 | Managed identity, RBAC, least privilege |
| AU (Audit) | AU-2, AU-3, AU-6 | Diagnostic settings, structured logging |
| CM (Configuration) | CM-2, CM-6 | Bicep IaC, pinned dependencies |
| IA (Identification) | IA-2, IA-5 | Azure AD, managed identity (no passwords) |
| SC (System/Comms) | SC-7, SC-8, SC-13 | Network isolation, TLS, CMK |
| SI (System Integrity) | SI-2, SI-4, SI-7 | Vulnerability scanning, monitoring, image signing |

### 10.4 HIPAA (if processing health org data)

If the Power Platform tenant contains healthcare apps, the governance data may be considered ePHI metadata. Additional controls:
- Execute a BAA with Microsoft for Azure services
- Enable CMK encryption (Section 5.1)
- Restrict access to governance data to minimum necessary
- Implement audit trail for all data access (Section 9.2)

---

## 11. Incident Response

### 11.1 Scenario: Managed Identity Credential Compromise

**Indicators:**
- Sign-in from unexpected IP or geography
- Token requests for scopes not used by the application
- Unusual API call patterns (e.g., write operations on Power Platform)

**Response:**
1. **Contain:** Disable the managed identity immediately via Azure Portal/CLI
2. **Assess:** Review Azure AD sign-in logs for the identity's `principalId`
3. **Investigate:** Check if any Power Platform resources were modified (the identity should be read-only)
4. **Recover:** Create a new managed identity, update role assignments, redeploy
5. **Report:** File security incident per organizational IR policy

### 11.2 Scenario: Governance Data Exfiltration

**Indicators:**
- Storage account access from unknown IPs (if public access wasn't disabled)
- Bulk download patterns in storage analytics
- SAS token creation events

**Response:**
1. **Contain:** Rotate storage account keys, revoke all SAS tokens, disable public access
2. **Assess:** Enumerate exactly which blobs were accessed using storage analytics logs
3. **Classify:** Determine PII exposure (UserIdentities.csv, connection URLs with internal hostnames)
4. **Notify:** Engage privacy/legal team if PII was exposed
5. **Remediate:** Enable private endpoints, implement all network controls from Section 4

### 11.3 Scenario: Supply Chain Attack (Compromised Dependency)

**Indicators:**
- Vulnerability advisory for a dependency (aiohttp, azure-identity, etc.)
- Unexpected network connections from the container
- Image scan findings after deployment

**Response:**
1. **Contain:** Pause the CRON schedule (scale Container App Job to 0 replicas)
2. **Assess:** Determine if the vulnerable version is in use (check pip freeze in image)
3. **Patch:** Update dependency, rebuild image, scan, deploy
4. **Investigate:** Review container logs for evidence of exploitation
5. **Harden:** Implement egress network controls (Section 4) to limit blast radius of future supply chain attacks

---

## 12. Hardening Checklist

Use this checklist during deployment reviews and periodic security assessments.

### Identity and Access
- [ ] User-Assigned Managed Identity created (not system-assigned)
- [ ] Managed identity has ONLY required API permissions (Section 3.1)
- [ ] PIM enabled for all human administrative access
- [ ] Conditional Access policy applied to workload identity
- [ ] Quarterly access reviews scheduled
- [ ] `allowSharedKeyAccess: false` on storage account
- [ ] No service principal client secrets in environment variables

### Network
- [ ] Container Apps environment deployed with VNet integration
- [ ] Private endpoints for Storage, ACR, Key Vault
- [ ] Storage account firewall set to `defaultAction: Deny`
- [ ] NSG rules restrict egress to required APIs only
- [ ] Private DNS zones configured for all private endpoints
- [ ] No public IP addresses on any resource

### Data Protection
- [ ] CMK encryption enabled via Key Vault
- [ ] Key rotation policy configured (90 days)
- [ ] TLS 1.2 minimum enforced on storage account
- [ ] Blob lifecycle policy configured (Section 5.3)
- [ ] Immutable storage enabled for compliance
- [ ] PII data (UserIdentities) in separate container with restricted RBAC

### Container
- [ ] Multi-stage Dockerfile with non-root user
- [ ] Base image pinned to SHA digest
- [ ] All dependencies version-pinned with lock file
- [ ] Image scanned for CVEs before deployment
- [ ] Image signed and signature verified at pull
- [ ] SBOM generated and stored

### Monitoring
- [ ] Diagnostic settings enabled for storage, container app, ACR
- [ ] Log Analytics workspace with appropriate retention
- [ ] Alert rules configured (Section 9.3)
- [ ] Heartbeat monitoring for scheduled job execution
- [ ] Security team has Reader access for audit

### Compliance
- [ ] Data classification applied (Section 2.3)
- [ ] Privacy review completed for PII collection
- [ ] Legal basis documented for employee monitoring data
- [ ] Compliance mapping reviewed with audit team
- [ ] Incident response playbooks tested

---

*This document should be reviewed and updated whenever the application's API permissions, network architecture, or data collection scope changes. Minimum review cadence: quarterly.*
