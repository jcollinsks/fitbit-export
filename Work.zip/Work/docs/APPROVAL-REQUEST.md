# Approval Request: Power Platform Enterprise Governance Report

**Requested by:** IT / Center of Excellence Team
**Date:** 2026-04-30
**Estimated Monthly Cost:** ~$55

---

## 1. Executive Summary

We are requesting approval to deploy a lightweight, read-only reporting tool that inventories our organization's Power Platform assets — approximately **3,000 environments, 40,000 apps, 80,000 flows**, plus connectors, DLP policies, Copilot agents, and solutions. The tool runs as a scheduled Python script on an Azure Web Job, writes CSV files to blob storage, and feeds a Power BI dashboard for governance. It uses no passwords, cannot modify anything in Power Platform, and costs approximately $55 per month.

---

## 2. What This Tool Does

A Python script runs once per day (estimated 60-90 minutes for our tenant size). It calls Microsoft's Power Platform REST APIs to read metadata — app names, owners, creation dates, connector usage, DLP policy assignments, etc. It writes 33 CSV files to Azure Blob Storage. Power BI reads those CSVs and displays dashboards for governance: orphaned apps, shadow IT detection, DLP compliance, ownership tracking, and Copilot agent inventory.

**It is strictly read-only. It never creates, modifies, or deletes anything.**

```
                              All traffic stays within Azure / Microsoft 365

+--------------------+        HTTPS (read-only)        +---------------------+
|                    | --------------------------------> |                     |
|  Azure Web Job     |                                  | Power Platform APIs |
|  (Python script)   | <-------------------------------- | (Microsoft 1st party)|
|                    |         Metadata only             +---------------------+
|  Runs daily,       |              |
|  ~60-90 min        |              | Also reads from:
|  15 envs parallel  |              |   - Microsoft Graph API
|                    |              |   - Dataverse API (per environment)
+--------------------+              |
        |                           |
        |--- writes CSV --->  Azure Blob Storage
                              33 files, ~2-5 GB
                                    |
                                    |--- reads CSVs --->  Power BI Dashboard
```

### What we see in the dashboard:
- Total inventory of all apps, flows, agents, and connectors across all 3,000 environments
- Who owns what — maker concentration, orphaned resources
- DLP compliance — which apps/flows violate data loss prevention policies
- Shadow IT detection — unmanaged flows, apps bypassing consent
- Copilot Studio agent inventory with authentication modes
- Solution awareness — what's managed vs. unmanaged

---

## 3. Azure Resources Required

| Resource | SKU / Tier | Purpose | Monthly Cost |
|---|---|---|---|
| App Service Plan | Standard S2 (2 cores, 3.5 GB RAM) | Runs the scheduled Web Job with enough memory for 3,000 environments | ~$50 |
| App Service (Web App) | Included in plan | Hosts the Web Job; no public web traffic served | Included |
| Storage Account | Standard GRS | Stores 33 CSV output files (~2-5 GB per daily run) | ~$2 |
| User-Assigned Managed Identity | Free | Passwordless authentication to APIs and Storage | Free |
| Log Analytics Workspace (optional) | Free tier (5 GB/mo) | Monitoring and diagnostics | Free |

**Total: ~$55/month**

Note: The Standard S2 tier is recommended for our tenant size (3,000 environments). After initial testing, this could potentially be downgraded to S1 ($25/mo) if the job completes within memory limits.

---

## 4. Permissions Required

| Permission | Scope | Justification | Risk Level |
|---|---|---|---|
| Power Platform Service Admin | Azure AD directory role | Read-only access to Power Platform metadata across all environments. Cannot modify tenant settings, delete resources, or change policies. This is the standard role Microsoft recommends for governance tooling. | **Low** — read-only admin |
| Storage Blob Data Contributor | Single storage account | Write CSV output files to the designated blob container | **Low** — scoped to one storage account |
| Microsoft Graph User.Read.All (optional) | Application permission | Resolve user GUIDs to display names for ownership reporting. Only enabled if user identity resolution is turned on. | **Low** — read-only |

### What these permissions DO NOT allow:
- Cannot create, modify, or delete any Power App, Flow, or environment
- Cannot change DLP policies or tenant settings
- Cannot access business data inside apps (SharePoint lists, Dataverse records, etc.)
- Cannot impersonate users or access their mailboxes
- Cannot modify Azure AD users, groups, or roles

**No client secrets or passwords are used.** All authentication is via Azure Managed Identity — there is nothing to rotate, no secrets in Key Vault, and no credentials in code or configuration.

---

## 5. Security Controls

- **No secrets or passwords** — Azure Managed Identity only
- **Read-only API access** — the tool cannot create, modify, or delete any Power Platform resource
- **Managed Identity is scoped** — only has the two permissions listed above
- **Storage account hardened:**
  - Public network access: Denied (firewall rules)
  - Geo-redundant storage (GRS) for data durability
  - TLS 1.2 minimum enforced
  - Shared key access disabled (Azure AD auth only — no storage account keys)
  - Blob lifecycle policy: cool after 30 days, delete after 365 days
- **Web App hardened:**
  - No public-facing endpoints needed (the app does not serve web traffic)
  - HTTPS only
  - Can be placed in a VNet with service endpoints if required
  - Always On enabled for reliable scheduled execution
- **Network:**
  - All outbound traffic is HTTPS to Microsoft first-party endpoints only
  - Endpoints contacted: `*.powerapps.com`, `*.flow.microsoft.com`, `*.bap.microsoft.com`, `*.crm.dynamics.com`, `graph.microsoft.com`, `*.blob.core.windows.net`
  - No third-party services, no external APIs, no SaaS products
  - No inbound connections required

---

## 6. Data Classification

### What IS collected (Classification: Internal / Confidential)

| Data | Example | Classification |
|---|---|---|
| Environment names and properties | "Production - Finance", type: Production | Internal |
| App and flow names | "Expense Report Approval Flow" | Internal |
| Owner email addresses | jsmith@company.com | Confidential (PII) |
| Connector and connection metadata | "SQL Server connector to server01.internal" | Confidential |
| DLP policy definitions | Policy names, connector classifications | Internal |
| Copilot agent configuration | Authentication mode, topic counts | Internal |
| Solution inventory | Solution names, publishers, version numbers | Internal |

### What is NOT collected

- No business data from inside apps, flows, or Dataverse tables
- No customer records, financial data, or regulated data (PHI, PCI, etc.)
- No file contents from SharePoint, OneDrive, or any data source
- No credentials, tokens, connection strings, or API keys
- No user passwords or multi-factor authentication data
- No message contents from Teams, email, or any communication channel

---

## 7. Network and Data Flow

```
    Your Azure Subscription                      Microsoft 365
    ========================                      =============

    +-------------------+     HTTPS (443)     +--------------------+
    |                   |  ---- read-only ---> | Power Platform API |
    |  App Service      |                     | (powerapps.com)    |
    |  Web Job          |  ---- read-only ---> | Flow API           |
    |  (Python 3.12)    |                     | (flow.microsoft)   |
    |                   |  ---- read-only ---> | Graph API          |
    |  Managed Identity |                     | (graph.microsoft)  |
    |  (no passwords)   |  ---- read-only ---> | Dataverse API      |
    |                   |                     | (crm.dynamics.com) |
    +-------------------+                     +--------------------+
            |
            | Writes CSV files (HTTPS)
            v
    +-------------------+
    | Storage Account   |
    | (Blob Storage)    |      No data leaves your Azure tenant.
    | 33 CSV files      |      No external services contacted.
    | GRS replicated    |      No inbound connections needed.
    +-------------------+
            |
            | Reads CSV files
            v
    +-------------------+
    | Power BI Service  |
    | (Dashboard)       |
    | Access controlled |
    | by workspace RBAC |
    +-------------------+
```

---

## 8. Cost Summary

| Item | Monthly Cost |
|---|---|
| App Service Plan (S2) | ~$50 |
| Storage Account (~5 GB, GRS) | ~$2 |
| Managed Identity | Free |
| Log Analytics (free tier) | Free |
| **Total** | **~$55/month** |

Cost can be reduced after initial testing:
- Downgrade to S1 ($25/mo) if the job runs within 1.75 GB RAM
- Switch to Standard_LRS storage (~$1/mo) if geo-redundancy isn't required
- **Minimum possible cost: ~$27/month**

---

## 9. Frequently Asked Questions

**Can this tool modify our Power Platform environment?**
No. It uses read-only API calls exclusively. It cannot create, update, or delete apps, flows, connectors, DLP policies, environments, or any other resource. The Power Platform Service Admin role is read-only.

**Does it store any passwords or secrets?**
No. It authenticates using Azure Managed Identity exclusively. There are no passwords, client secrets, certificates, or API keys to manage, rotate, or protect.

**What data leaves our tenant?**
None. All data stays within your Azure subscription. The tool reads from Microsoft APIs (which are already in your M365 tenant) and writes to a storage account in your subscription.

**What happens if the tool stops running?**
Nothing breaks. The CSV files remain in storage, and the Power BI dashboard shows the last collected data. No Power Platform functionality is affected. There is no dependency — Power Platform does not know this tool exists.

**Why does it need Power Platform Service Admin?**
This is the only Azure AD role that provides tenant-wide read access to Power Platform metadata across all environments. It is Microsoft's recommended role for governance and CoE tooling. It cannot modify tenant settings, delete resources, or change DLP policies.

**How long does it take to run?**
For our tenant (~3,000 environments, 40,000 apps, 80,000 flows), we estimate 60-90 minutes per daily run. The tool processes 15 environments in parallel with built-in rate limiting and retry logic to respect Microsoft's API throttling.

**Can we restrict network access further?**
Yes. The Web App can be VNet-integrated with service endpoints for the storage account. The storage account already denies public access by default. No inbound network access is required — the tool only makes outbound HTTPS calls.

**Is there open-source precedent for this?**
Yes. Microsoft's own Center of Excellence (CoE) Starter Kit performs similar data collection. This tool is a custom alternative that writes to standard CSV/Power BI instead of requiring Dataverse licensing.

**Who can see the Power BI dashboard?**
Only users with access to the Power BI workspace. Dashboard access is managed through standard Power BI workspace roles (Admin, Member, Contributor, Viewer).

**What if we need to stop or remove it?**
Delete the resource group. All Azure resources, the managed identity, and stored data are removed. No residual permissions remain in Power Platform. There are no agents, connectors, or components installed inside Power Platform.

---

*For technical details, see the deployment guide, security guide, and architecture documentation in the project repository. For questions, contact the requesting team.*
