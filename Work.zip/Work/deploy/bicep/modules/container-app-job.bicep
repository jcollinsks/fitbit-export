@description('Azure region')
param location string

@description('Environment name for resource naming')
param environmentName string

@description('CRON schedule expression')
param cronSchedule string

@description('Full container image reference')
param containerImage string

@description('User-Assigned Managed Identity resource ID')
param identityId string

@description('User-Assigned Managed Identity client ID')
param identityClientId string

@description('Storage account name')
param storageAccountName string

@description('Storage container name')
param storageContainerName string = 'pp-export'

@description('Subnet resource ID for VNet integration')
param infrastructureSubnetId string = ''

@description('Log Analytics workspace ID for diagnostics')
param logAnalyticsWorkspaceId string = ''

resource containerAppEnvironment 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: '${environmentName}-env'
  location: location
  properties: {
    zoneRedundant: true
    vnetConfiguration: infrastructureSubnetId != '' ? {
      infrastructureSubnetId: infrastructureSubnetId
      internal: true
    } : null
    appLogsConfiguration: logAnalyticsWorkspaceId != '' ? {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalyticsWorkspaceId
      }
    } : null
  }
}

resource containerAppJob 'Microsoft.App/jobs@2023-05-01' = {
  name: '${environmentName}-job'
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    environmentId: containerAppEnvironment.id
    configuration: {
      triggerType: 'Schedule'
      scheduleTriggerConfig: {
        cronExpression: cronSchedule
        parallelism: 1
        replicaCompletionCount: 1
      }
      replicaTimeout: 7200
      replicaRetryLimit: 1
      registries: [
        {
          server: split(containerImage, '/')[0]
          identity: identityId
        }
      ]
    }
    template: {
      containers: [
        {
          name: 'pp-export'
          image: containerImage
          resources: {
            cpu: json('2.0')
            memory: '4Gi'
          }
          env: [
            {
              name: 'AZURE_CLIENT_ID'
              value: identityClientId
            }
            {
              name: 'PP_EXPORT_STORAGE_ACCOUNT_NAME'
              value: storageAccountName
            }
            {
              name: 'PP_EXPORT_STORAGE_CONTAINER_NAME'
              value: storageContainerName
            }
            {
              name: 'PP_EXPORT_ENV_CONCURRENCY'
              value: '15'
            }
            {
              name: 'PP_EXPORT_LOG_LEVEL'
              value: 'INFO'
            }
          ]
        }
      ]
    }
  }
}

output jobName string = containerAppJob.name
output environmentId string = containerAppEnvironment.id
