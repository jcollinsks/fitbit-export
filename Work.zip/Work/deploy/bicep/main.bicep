@description('Azure region for all resources')
param location string = resourceGroup().location

@description('Environment name used as prefix for resources')
param environmentName string

@description('CRON schedule for the export job (default: 2 AM daily)')
param cronSchedule string = '0 2 * * *'

@description('Storage account name')
param storageAccountName string

@description('Container registry name')
param containerRegistryName string

@description('Container image name')
param imageName string = 'pp-export'

@description('Container image tag')
param imageTag string = 'latest'

@description('VNet subnet resource ID for Container Apps (optional, required for enterprise)')
param containerAppSubnetId string = ''

@description('VNet subnet resource ID for private endpoints (optional)')
param privateEndpointSubnetId string = ''

@description('Log Analytics workspace customer ID (optional, for diagnostics)')
param logAnalyticsWorkspaceId string = ''

// User-Assigned Managed Identity
module identity 'modules/identity.bicep' = {
  name: 'identity'
  params: {
    location: location
    identityName: '${environmentName}-identity'
  }
}

// Storage Account + Blob Container + Role Assignment
module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: {
    location: location
    storageAccountName: storageAccountName
    principalId: identity.outputs.principalId
    allowedSubnetId: containerAppSubnetId
  }
}

// Azure Container Registry + AcrPull Role Assignment
module acr 'modules/container-registry.bicep' = {
  name: 'acr'
  params: {
    location: location
    registryName: containerRegistryName
    principalId: identity.outputs.principalId
  }
}

// Container Apps Environment + Scheduled Job
module job 'modules/container-app-job.bicep' = {
  name: 'job'
  params: {
    location: location
    environmentName: environmentName
    cronSchedule: cronSchedule
    containerImage: '${acr.outputs.loginServer}/${imageName}:${imageTag}'
    identityId: identity.outputs.identityId
    identityClientId: identity.outputs.clientId
    storageAccountName: storage.outputs.storageAccountName
    infrastructureSubnetId: containerAppSubnetId
    logAnalyticsWorkspaceId: logAnalyticsWorkspaceId
  }
}

output identityPrincipalId string = identity.outputs.principalId
output identityClientId string = identity.outputs.clientId
output storageAccountName string = storage.outputs.storageAccountName
output registryLoginServer string = acr.outputs.loginServer
output jobName string = job.outputs.jobName
