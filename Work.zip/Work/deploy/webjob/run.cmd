@echo off
REM Azure Web Job runner - installs dependencies and runs the export
echo [%date% %time%] Starting Power Platform Governance Export...

REM Install dependencies (cached after first run)
python -m pip install --quiet --disable-pip-version-check -r requirements.txt

REM Run the export
python run.py

echo [%date% %time%] Export finished with exit code %ERRORLEVEL%
exit /b %ERRORLEVEL%
