"""Azure Web Job entry point for Power Platform Governance Export.

This script is executed by the Azure Web Job scheduler (CRON trigger).
It runs the pp_export module with Azure Blob Storage backend using
the Web App's Managed Identity for authentication.

Environment variables (set in App Service Configuration):
    PP_EXPORT_STORAGE_ACCOUNT_NAME  - Target storage account
    PP_EXPORT_STORAGE_CONTAINER_NAME - Blob container (default: pp-export)
    PP_EXPORT_ENV_CONCURRENCY       - Max parallel environments (default: 15)
    PP_EXPORT_LOG_LEVEL             - Logging level (default: INFO)
    AZURE_CLIENT_ID                 - Managed Identity client ID
"""
import asyncio
import sys
import os
from datetime import datetime, UTC

# Add the src directory to the path so pp_export can be found
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from pp_export.cli import parse_args
from pp_export.main import run_export
from pp_export.observability.logging import configure_logging


def main():
    # Use date-based prefix so each day's export is in its own folder
    date_prefix = datetime.now(UTC).strftime("%Y-%m-%d") + "/"
    os.environ.setdefault("PP_EXPORT_OUTPUT_PREFIX", date_prefix)

    # Default to azure storage backend
    os.environ.setdefault("PP_EXPORT_STORAGE_BACKEND", "azure")

    settings = parse_args([])
    configure_logging(log_level=settings.log_level)

    print(f"Starting Power Platform export at {datetime.now(UTC).isoformat()}")
    print(f"Storage: {settings.storage_account_name}/{settings.storage_container_name}")
    print(f"Output prefix: {settings.output_prefix}")

    try:
        asyncio.run(run_export(settings))
        print(f"Export completed successfully at {datetime.now(UTC).isoformat()}")
    except Exception as exc:
        print(f"Export failed: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
