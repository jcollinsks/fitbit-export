"""Deploy the Power Platform Governance Export as an Azure Web Job.

Usage:
    python deploy_webjob.py --subscription-id XXXX --resource-group rg-ppgov --location eastus2

This script:
  1. Creates the Azure resources (App Service Plan, Web App, Storage, Managed Identity)
  2. Assigns the required permissions
  3. Packages the Web Job ZIP
  4. Deploys the Web Job to the App Service
  5. Assigns Power Platform Admin role to the Managed Identity
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import uuid
import zipfile
from pathlib import Path


def az(cmd: str, **kwargs) -> dict | list | str | None:
    """Run an az CLI command and return parsed JSON output."""
    full_cmd = f"az {cmd} -o json"
    result = subprocess.run(full_cmd, shell=True, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "already exists" in stderr.lower():
            return None
        print(f"  az error: {stderr[:300]}")
        return None
    if result.stdout.strip():
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout.strip()
    return None


def az_rest(method: str, url: str, body: dict | None = None) -> dict | None:
    """Call az rest."""
    cmd = f'az rest --method {method} --url "{url}"'
    if body:
        body_json = json.dumps(body).replace('"', '\\"')
        cmd += f' --body "{body_json}"'
    cmd += " -o json"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  REST error: {result.stderr[:300]}")
        return None
    try:
        return json.loads(result.stdout)
    except (json.JSONDecodeError, ValueError):
        return None


def create_webjob_zip(script_dir: Path, output_path: Path) -> None:
    """Package the Web Job as a ZIP file."""
    src_dir = script_dir / "src"
    wj_dir = script_dir / "webjob"

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # Add the web job files
        for fn in ("run.py", "run.cmd", "settings.job", "requirements.txt"):
            fpath = wj_dir / fn
            if fpath.exists():
                zf.write(fpath, f"App_Data/jobs/triggered/pp-export/{fn}")

        # Add the source package
        for root, dirs, files in os.walk(src_dir):
            # Skip __pycache__
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for fn in files:
                if fn.endswith((".py", ".pyi")):
                    fpath = Path(root) / fn
                    arcname = f"App_Data/jobs/triggered/pp-export/src/{fpath.relative_to(src_dir)}"
                    zf.write(fpath, arcname)

        # Add pyproject.toml for reference
        pyproject = script_dir / "pyproject.toml"
        if pyproject.exists():
            zf.write(pyproject, "App_Data/jobs/triggered/pp-export/pyproject.toml")

    print(f"  Web Job ZIP: {output_path} ({output_path.stat().st_size:,} bytes)")


def main() -> None:
    parser = argparse.ArgumentParser(description="Deploy Power Platform Governance Export as Azure Web Job")
    parser.add_argument("--subscription-id", required=True, help="Azure subscription ID")
    parser.add_argument("--resource-group", default="rg-ppgov-prod", help="Resource group name")
    parser.add_argument("--location", default="eastus2", help="Azure region")
    parser.add_argument("--plan-name", default="asp-ppgov-prod", help="App Service Plan name")
    parser.add_argument("--app-name", default="app-ppgov-prod", help="Web App name (must be globally unique)")
    parser.add_argument("--sku", default="S2", choices=["B1", "B2", "S1", "S2", "S3", "P1V2", "P2V2"],
                        help="App Service Plan SKU (default: S2 for large tenants)")
    parser.add_argument("--storage-name", default="stppgovprod", help="Storage account name")
    parser.add_argument("--identity-name", default="id-ppgov-prod", help="Managed Identity name")
    parser.add_argument("--skip-infra", action="store_true", help="Skip resource creation, just deploy the Web Job")
    parser.add_argument("--assign-pp-admin", action="store_true", help="Assign Power Platform Admin role to the Managed Identity")
    args = parser.parse_args()

    script_dir = Path(__file__).parent.resolve()
    sub_id = args.subscription_id
    rg = args.resource_group
    loc = args.location

    print("=" * 60)
    print("  Power Platform Governance - Web Job Deployment")
    print("=" * 60)
    print(f"  Subscription: {sub_id}")
    print(f"  Resource Group: {rg}")
    print(f"  Location: {loc}")
    print("=" * 60)
    print()

    # Set subscription
    print("[0] Setting subscription...")
    az(f"account set --subscription {sub_id}")

    if not args.skip_infra:
        # ── Step 1: Resource Group ─────────────────────────────────
        print("\n[1/7] Creating resource group...")
        az(f'group create --name {rg} --location {loc} --tags application=ppgov environment=production')
        print(f"  Resource group: {rg}")

        # ── Step 2: Managed Identity ──────────────────────────────
        print("\n[2/7] Creating managed identity...")
        identity = az(f'identity create --resource-group {rg} --name {args.identity_name} --location {loc}')
        if identity:
            identity_id = identity["id"]
            principal_id = identity["principalId"]
            client_id = identity["clientId"]
        else:
            identity = az(f'identity show --resource-group {rg} --name {args.identity_name}')
            identity_id = identity["id"]
            principal_id = identity["principalId"]
            client_id = identity["clientId"]
        print(f"  Identity: {args.identity_name}")
        print(f"  Client ID: {client_id}")
        print(f"  Principal ID: {principal_id}")

        # ── Step 3: Storage Account ───────────────────────────────
        print("\n[3/7] Creating storage account...")
        az(f'storage account create --resource-group {rg} --name {args.storage_name} --location {loc} '
           f'--sku Standard_GRS --kind StorageV2 --min-tls-version TLS1_2 '
           f'--allow-blob-public-access false --https-only true')

        # Create container
        storage_key = az(f'storage account keys list --account-name {args.storage_name} --resource-group {rg} --query "[0].value"')
        if storage_key:
            az(f'storage container create --name pp-export --account-name {args.storage_name} --account-key {storage_key}')
        print(f"  Storage: {args.storage_name}/pp-export")

        # Assign Storage Blob Data Contributor
        print("  Assigning storage role...")
        storage_id = f"/subscriptions/{sub_id}/resourceGroups/{rg}/providers/Microsoft.Storage/storageAccounts/{args.storage_name}"
        role_uuid = str(uuid.uuid4())
        az_rest("PUT",
                f"https://management.azure.com{storage_id}/providers/Microsoft.Authorization/roleAssignments/{role_uuid}?api-version=2022-04-01",
                {"properties": {
                    "roleDefinitionId": f"/subscriptions/{sub_id}/providers/Microsoft.Authorization/roleDefinitions/ba92f5b4-2d11-453d-a403-e96b0029c9fe",
                    "principalId": principal_id,
                    "principalType": "ServicePrincipal",
                }})
        print("  Role: Storage Blob Data Contributor")

        # ── Step 4: App Service Plan ──────────────────────────────
        print("\n[4/7] Creating App Service Plan...")
        az(f'appservice plan create --resource-group {rg} --name {args.plan_name} --location {loc} '
           f'--sku {args.sku} --is-linux')
        print(f"  Plan: {args.plan_name} (B1 Linux)")

        # ── Step 5: Web App ───────────────────────────────────────
        print("\n[5/7] Creating Web App...")
        az(f'webapp create --resource-group {rg} --plan {args.plan_name} --name {args.app_name} '
           f'--runtime "PYTHON:3.12" --assign-identity [system]')

        # Assign the user-assigned managed identity
        os.environ["MSYS_NO_PATHCONV"] = "1"
        az(f'webapp identity assign --resource-group {rg} --name {args.app_name} --identities {identity_id}')
        os.environ.pop("MSYS_NO_PATHCONV", None)

        # Configure app settings
        print("  Configuring environment variables...")
        az(f'webapp config appsettings set --resource-group {rg} --name {args.app_name} --settings '
           f'AZURE_CLIENT_ID={client_id} '
           f'PP_EXPORT_STORAGE_ACCOUNT_NAME={args.storage_name} '
           f'PP_EXPORT_STORAGE_CONTAINER_NAME=pp-export '
           f'PP_EXPORT_ENV_CONCURRENCY=10 '
           f'PP_EXPORT_FLOW_DEF_CONCURRENCY=5 '
           f'PP_EXPORT_CONNECTION_DETAIL_CONCURRENCY=5 '
           f'PP_EXPORT_ENV_TIMEOUT_MINUTES=0 '
           f'PP_EXPORT_MAX_RETRIES_429=8 '
           f'PP_EXPORT_HTTP_TIMEOUT_SECONDS=120 '
           f'PP_EXPORT_LOG_LEVEL=INFO '
           f'SCM_DO_BUILD_DURING_DEPLOYMENT=true '
           f'WEBSITE_WEBJOB_ALWAYS_ON_ENABLED=1')

        # Enable Always On (required for triggered web jobs on schedule)
        az(f'webapp config set --resource-group {rg} --name {args.app_name} --always-on true')
        print(f"  Web App: {args.app_name}")

        # ── Step 6: Power Platform Admin Role ─────────────────────
        if args.assign_pp_admin:
            print("\n[6/7] Assigning Power Platform Admin role...")
            result = az_rest("POST",
                "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments",
                {
                    "@odata.type": "#microsoft.graph.unifiedRoleAssignment",
                    "principalId": principal_id,
                    "roleDefinitionId": "11648597-926c-4cf3-9c36-bcebb0ba8dcc",
                    "directoryScopeId": "/",
                })
            if result:
                print("  Role: Power Platform Service Admin (read-only)")
            else:
                print("  Note: May need Global Admin to assign this role.")
                print(f"  Principal ID to assign: {principal_id}")
        else:
            print("\n[6/7] Skipping PP Admin role (use --assign-pp-admin to enable)")
            print(f"  Your Azure AD admin needs to assign 'Power Platform Service Admin' to:")
            print(f"  Principal ID: {principal_id}")
    else:
        print("Skipping infrastructure creation (--skip-infra)")
        identity = az(f'identity show --resource-group {rg} --name {args.identity_name}')
        client_id = identity["clientId"] if identity else "unknown"

    # ── Step 7: Deploy Web Job ────────────────────────────────
    print("\n[7/7] Deploying Web Job...")
    zip_path = Path(tempfile.mkdtemp()) / "pp-export-webjob.zip"
    create_webjob_zip(script_dir, zip_path)

    az(f'webapp deployment source config-zip --resource-group {rg} --name {args.app_name} --src "{zip_path}"')
    print("  Web Job deployed!")

    # Clean up
    zip_path.unlink(missing_ok=True)

    print()
    print("=" * 60)
    print("  Deployment Complete!")
    print("=" * 60)
    print()
    print(f"  Web App:        https://{args.app_name}.azurewebsites.net")
    print(f"  Web Job Portal: https://{args.app_name}.scm.azurewebsites.net/azurejobs/#/jobs")
    print(f"  Storage:        https://{args.storage_name}.blob.core.windows.net/pp-export")
    print(f"  Schedule:       Daily at 2:00 AM UTC")
    print()
    print("  To trigger a manual run:")
    print(f"    az webapp webjob triggered run --resource-group {rg} --name {args.app_name} --webjob-name pp-export")
    print()
    print("  To view logs:")
    print(f"    az webapp log tail --resource-group {rg} --name {args.app_name}")
    print()
    if not args.skip_infra and not args.assign_pp_admin:
        print("  IMPORTANT: Ask your Azure AD admin to assign 'Power Platform Service Admin'")
        print(f"  role to Managed Identity principal: {identity['principalId'] if identity else 'see above'}")
        print()


if __name__ == "__main__":
    main()
