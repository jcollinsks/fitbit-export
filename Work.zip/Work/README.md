# Power Platform Enterprise Governance - Deployment Package

## Quick Links

| Document | Audience | Purpose |
|----------|----------|---------|
| [Approval Request](docs/APPROVAL-REQUEST.md) | Azure team, Security team | What we need and why — send this first |
| [Security Guide](docs/SECURITY-GUIDE.md) | Security team | Detailed security controls, compliance mapping, hardening checklist |
| [Deployment Guide](docs/DEPLOYMENT-GUIDE.md) | Platform engineering | Step-by-step Azure deployment instructions |
| [Architecture](docs/architecture.md) | Technical reviewers | System design and data flow |
| [Issues Analysis](docs/ISSUES-ANALYSIS.md) | Development team | Known issues and fixes applied to the codebase |

## Folder Structure

```
Work/
  docs/                      Approval, security, and deployment documentation
    APPROVAL-REQUEST.md        Start here - send to Azure & Security teams
    SECURITY-GUIDE.md          Full security review document
    DEPLOYMENT-GUIDE.md        Step-by-step deployment instructions
    architecture.md            System architecture
    ISSUES-ANALYSIS.md         Codebase issues found and fixed

  deploy/                    Deployment artifacts
    deploy_webjob.py           One-command Azure deployment script
    webjob/                    Azure Web Job files
      run.py                     Entry point
      run.cmd                    Windows runner
      settings.job               CRON schedule (daily 2 AM UTC)
      requirements.txt           Python dependencies
    gitlab/                    GitLab CI/CD pipeline
      .gitlab-ci.yml             Test, build, deploy pipeline
    bicep/                     Infrastructure-as-Code (alternative to Web Job)
      main.bicep                 Container App Job deployment
      modules/                   Bicep modules for identity, storage, ACR, etc.
```

## Deployment Options

| Option | Status | Monthly Cost | Best For |
|--------|--------|-------------|----------|
| **Azure Web Job** | Recommended | ~$55 | Enterprise (no container approval needed) |
| Azure Container App Job | Available | ~$15 | Teams with container approval |
| Local (manual) | Available | Free | Testing and development |

## Getting Started

1. **Get approval:** Send `docs/APPROVAL-REQUEST.md` to your Azure and Security teams
2. **Deploy:** Run `python deploy/deploy_webjob.py --subscription-id YOUR_SUB --assign-pp-admin`
3. **View data:** Open the Power BI report or connect Power BI Service to the storage account
